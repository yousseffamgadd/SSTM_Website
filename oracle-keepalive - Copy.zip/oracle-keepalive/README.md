# Oracle Cloud idle keep-alive

Oracle reclaims (stops) Always Free compute instances it considers idle. One of its conditions is CPU usage below 20% at the 95th percentile over 7 days. This pod keeps the machine at about 25% CPU so it is never counted as idle. Check Oracle's current Always Free documentation for the exact rules, since they can change.

It runs in the `default` namespace and is built to stay out of the way. It has the lowest Kubernetes priority (evicted first, never pushes other pods out) and the lowest Linux CPU priority (nice 19, tiny CPU weight), so your websites and database always get CPU first. The kernel caps it at 25% of the node no matter what. It has no network access and runs as an unprivileged user with a read-only filesystem.

## Use

```bash
cd /home/ubuntu/oracle-keepalive
chmod +x keepalive.sh
./keepalive.sh            # deploy at 25% of total CPU
./keepalive.sh status     # wait a minute first; measures the machine's real CPU usage
./keepalive.sh 30         # change the target to 30%
./keepalive.sh remove     # remove it
```

`status` measures total CPU from `/proc/stat` over 10 seconds, which is what Oracle's monitoring sees. It should report 20% or more. You can also check in the Oracle Console under your instance → Metrics → CPU Utilization.

Upgrading the account to Pay As You Go is the clean alternative: Always Free resources stay free on a PAYG account and are not subject to idle reclamation.
