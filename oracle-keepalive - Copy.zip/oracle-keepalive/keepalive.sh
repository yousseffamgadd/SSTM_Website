#!/usr/bin/env bash
# Oracle Cloud idle keep-alive pod (namespace "default").
#
#   ./keepalive.sh              deploy (or update) at 25% of the node's total CPU
#   ./keepalive.sh 30           deploy at 30% instead
#   ./keepalive.sh status       show the pod and measure this machine's real CPU usage
#   ./keepalive.sh remove       delete the keep-alive pod
#
# Oracle reclaims Always Free instances whose CPU stays under 20% (95th percentile
# over 7 days). The default 25% keeps a safety margin above that. The pod runs at the
# lowest priority, so your websites and database always get CPU first.
set -euo pipefail
cd "$(dirname "$0")"

IMAGE="busybox:1.36.1"
NS="default"
DEFAULT_PERCENT=25

measure_cpu() {
  # Whole-machine CPU usage over 10 seconds, from /proc/stat (what Oracle's monitoring sees)
  read -r _ u1 n1 s1 i1 w1 q1 sq1 st1 _ < /proc/stat
  sleep 10
  read -r _ u2 n2 s2 i2 w2 q2 sq2 st2 _ < /proc/stat
  local busy=$(( (u2+n2+s2+q2+sq2+st2) - (u1+n1+s1+q1+sq1+st1) ))
  local idle=$(( (i2+w2) - (i1+w1) ))
  echo $(( 100 * busy / (busy + idle) ))
}

case "${1:-deploy}" in
  status)
    kubectl -n "$NS" get deploy,pods -l app=oracle-keepalive -o wide 2>/dev/null || true
    kubectl -n "$NS" logs deploy/oracle-keepalive --tail=1 2>/dev/null || true
    echo "Measuring this machine's total CPU usage for 10 seconds..."
    pct=$(measure_cpu)
    if [ "$pct" -ge 20 ]; then
      echo "Total CPU usage: ${pct}%  -> above Oracle's 20% idle threshold"
    else
      echo "Total CPU usage: ${pct}%  -> BELOW 20%: raise the target, e.g. ./keepalive.sh 30"
    fi
    exit 0 ;;
  remove)
    kubectl -n "$NS" delete deployment oracle-keepalive --ignore-not-found
    kubectl -n "$NS" delete networkpolicy oracle-keepalive-no-network --ignore-not-found
    kubectl delete priorityclass keepalive-lowest --ignore-not-found
    echo "Keep-alive removed."
    exit 0 ;;
  deploy) PERCENT=$DEFAULT_PERCENT ;;
  *[!0-9]*|'') echo "Usage: $0 [percent|status|remove]" >&2; exit 1 ;;
  *) PERCENT=$1 ;;
esac

if [ "$PERCENT" -lt 21 ] || [ "$PERCENT" -gt 50 ]; then
  echo "Percent must be between 21 and 50 (Oracle's threshold is 20%)." >&2
  exit 1
fi

# Size the cap from the node's CPU count
CPUS=$(kubectl get nodes -o jsonpath='{.items[0].status.capacity.cpu}')
case "$CPUS" in
  *m) MILLI_TOTAL=${CPUS%m} ;;
  *)  MILLI_TOTAL=$(( CPUS * 1000 )) ;;
esac
CPU_LIMIT=$(( MILLI_TOTAL * PERCENT / 100 ))m
WORKERS=$(( (MILLI_TOTAL * PERCENT / 100 + 999) / 1000 ))
echo ">> Node has $CPUS CPU(s): keep-alive capped at $CPU_LIMIT ($PERCENT%) with $WORKERS worker(s)"

# Preload the image so the pod never needs to pull from the internet
if ! sudo crictl inspecti "docker.io/library/$IMAGE" >/dev/null 2>&1; then
  echo ">> Loading $IMAGE into containerd"
  if command -v docker >/dev/null 2>&1; then
    docker pull "$IMAGE" && docker save "$IMAGE" | sudo ctr -n k8s.io images import -
  else
    sudo ctr -n k8s.io images pull "docker.io/library/$IMAGE"
  fi
fi

sed -e "s/__CPU_LIMIT__/$CPU_LIMIT/g" -e "s/__WORKERS__/$WORKERS/g" keepalive.yaml.template | kubectl apply -f -
kubectl -n "$NS" rollout status deployment/oracle-keepalive --timeout=120s

echo
echo "Done. Wait a minute, then check the real usage with:  ./keepalive.sh status"
