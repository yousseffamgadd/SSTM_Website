#!/usr/bin/env bash
# Checks, on the live cluster, that:
#   1. both pods are running
#   2. the database is exposed ONLY as a ClusterIP Service (nothing reachable from outside)
#   3. the website talks to the database through that ClusterIP (no Neon / external DB)
#   4. data submitted on the website lands in the PostgreSQL pod
#   5. other pods cannot reach the database (NetworkPolicy)
#   6. the database pod cannot reach the internet (offline)
#   7. the website is public on port 80 with DoS protection active
set -uo pipefail
NS="sstm"
PASS=0; FAIL=0; WARN=0
ok()   { echo "  [PASS] $*"; PASS=$((PASS+1)); }
bad()  { echo "  [FAIL] $*"; FAIL=$((FAIL+1)); }
warn() { echo "  [WARN] $*"; WARN=$((WARN+1)); }

echo "1) Pods"
for sel in app=postgres app=sstm-web; do
  ready=$(kubectl -n $NS get pods -l $sel -o jsonpath='{range .items[*]}{.status.containerStatuses[0].ready}{" "}{end}')
  if [ -n "$ready" ] && ! echo "$ready" | grep -q false; then ok "$sel ready ($ready)"; else bad "$sel not ready: '$ready'"; fi
done

echo "2) Database Service"
type=$(kubectl -n $NS get svc postgres -o jsonpath='{.spec.type}' 2>/dev/null)
ip=$(kubectl -n $NS get svc postgres -o jsonpath='{.spec.clusterIP}' 2>/dev/null)
if [ "$type" = "ClusterIP" ] && [ -n "$ip" ] && [ "$ip" != "None" ]; then ok "postgres is ClusterIP $ip:5432"; else bad "postgres service type='$type' ip='$ip'"; fi
exposed=$(kubectl -n $NS get svc -l app=postgres -o jsonpath='{range .items[*]}{.metadata.name}={.spec.type}{" "}{end}' | tr ' ' '\n' | grep -E "NodePort|LoadBalancer" || true)
if [ -z "$exposed" ]; then ok "no NodePort/LoadBalancer for postgres"; else bad "postgres exposed outside cluster: $exposed"; fi
if kubectl get ingress -A 2>/dev/null | grep -q postgres; then bad "an Ingress points at postgres"; else ok "no Ingress for postgres"; fi
eps=$(kubectl -n $NS get endpoints postgres -o jsonpath='{.subsets[*].addresses[*].ip}')
[ -n "$eps" ] && ok "ClusterIP routes to postgres pod $eps" || bad "postgres Service has no endpoints"

echo "3) Website -> database connection"
url=$(kubectl -n $NS exec deploy/sstm-web -- printenv DATABASE_URL 2>/dev/null)
host=$(echo "$url" | sed -E 's#.*@([^:/]+).*#\1#')
if [ "$host" = "postgres.sstm.svc.cluster.local" ] || [ "$host" = "postgres" ]; then ok "DATABASE_URL host is in-cluster service ($host)"; else bad "DATABASE_URL host is '$host'"; fi
if echo "$url" | grep -qi neon; then bad "DATABASE_URL still references Neon"; else ok "no Neon in DATABASE_URL"; fi
resolved=$(kubectl -n $NS exec deploy/sstm-web -- node -e "require('dns').lookup('$host',(e,a)=>console.log(e?'ERR':a))" 2>/dev/null)
[ "$resolved" = "$ip" ] && ok "$host resolves to ClusterIP $ip" || bad "$host resolves to '$resolved' (expected $ip)"
ready=$(kubectl -n $NS exec deploy/sstm-web -- node -e "fetch('http://localhost:3000/readyz').then(r=>console.log(r.status))" 2>/dev/null)
[ "$ready" = "200" ] && ok "website can query the database (/readyz 200)" || bad "website /readyz returned '$ready'"

echo "4) Data flow website -> PostgreSQL pod"
id=$(kubectl -n $NS exec deploy/sstm-web -- node -e "
fetch('http://localhost:3000/api/issues',{method:'POST',headers:{'content-type':'application/json'},
 body:JSON.stringify({category:'Site Visit',contact_number:'000',name:'verify.sh test',company:'verify.sh test'})})
.then(r=>r.json()).then(j=>console.log(j.issueId||'ERR'))" 2>/dev/null)
if [[ "$id" =~ ^[0-9]+$ ]]; then
  row=$(kubectl -n $NS exec postgres-0 -- sh -c "psql -U \"\$POSTGRES_USER\" -d \"\$POSTGRES_DB\" -tAc \"SELECT name FROM issues WHERE id=$id\"")
  [ "$row" = "verify.sh test" ] && ok "ticket #$id submitted via website is stored in postgres-0" || bad "ticket #$id not found in postgres-0"
  kubectl -n $NS exec postgres-0 -- sh -c "psql -U \"\$POSTGRES_USER\" -d \"\$POSTGRES_DB\" -qc \"DELETE FROM issues WHERE id=$id\"" >/dev/null && echo "         (test ticket removed)"
else
  bad "could not submit a test ticket (got '$id')"
fi

echo "5) Only the website may reach the database"
np=$(kubectl -n $NS get networkpolicy -o name 2>/dev/null | wc -l)
[ "$np" -ge 3 ] && ok "$np NetworkPolicies present" || bad "NetworkPolicies missing"
# Runs in the "default" namespace (no policies there), so only postgres's own
# ingress rule can block it.
out=$(kubectl -n default run sstm-netcheck --rm -i --restart=Never --quiet \
      --image=postgres:17-alpine --image-pull-policy=IfNotPresent \
      --command -- pg_isready -h postgres.sstm.svc.cluster.local -p 5432 -t 5 2>&1 || true)
if echo "$out" | grep -q "accepting connections"; then
  warn "an unrelated pod COULD reach postgres: your CNI is not enforcing NetworkPolicy (e.g. Flannel). See README."
else
  ok "unrelated pod blocked from postgres ($(echo "$out" | tail -1))"
fi

echo "6) Database pod is offline"
if kubectl -n $NS exec postgres-0 -- sh -c "wget -q -T 5 -O /dev/null http://1.1.1.1" >/dev/null 2>&1; then
  warn "postgres-0 CAN reach the internet: CNI is not enforcing NetworkPolicy. See README."
else
  ok "postgres-0 has no internet access"
fi

echo "7) Public access and DoS protection"
etp=$(kubectl -n $NS get svc sstm-web -o jsonpath='{.spec.externalTrafficPolicy}')
eip=$(kubectl -n $NS get svc sstm-web -o jsonpath='{.spec.externalIPs[0]}')
[ "$etp" = "Local" ] && ok "visitor IPs preserved (externalTrafficPolicy=Local)" || bad "externalTrafficPolicy is '$etp' (per-IP limits won't work)"
[ -n "$eip" ] && ok "website served on port 80 at $eip (Oracle maps the public IP here)" || bad "no externalIPs on sstm-web (port 80 not served)"
lim=$(kubectl -n $NS exec deploy/sstm-web -- printenv RATE_LIMIT_PER_MIN 2>/dev/null)
[ -n "$lim" ] && ok "app rate limit active ($lim requests/min per IP)" || bad "app rate limit settings missing"
if sudo -n true 2>/dev/null; then
  if sudo iptables -t raw -S SSTM-DOS >/dev/null 2>&1; then ok "host packet-rate firewall active (sudo ./host-firewall.sh status)"
  else bad "host packet-rate firewall not installed: run sudo ./host-firewall.sh"; fi
else
  warn "can't check host firewall without sudo: run sudo ./host-firewall.sh status"
fi

echo
echo "Result: $PASS passed, $FAIL failed, $WARN warnings"
[ "$FAIL" -eq 0 ]
