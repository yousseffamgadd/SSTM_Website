// Standalone server that replaces the Vercel runtime for Kubernetes.
// - /api/<name>  -> api/<name>.js  (files starting with "_" are private, like on Vercel)
// - everything else -> static files from public/
// No extra dependencies: uses Node's built-in http module.

require("dotenv").config();

const http = require("http");
const fs = require("fs");
const path = require("path");
const { getPool } = require("./api/_db");
const { clientIp, hit, limitConnectionsPerIp } = require("./ratelimit");

const PORT = Number(process.env.PORT || 3000);
const PUBLIC_DIR = path.join(__dirname, "public");
const API_DIR = path.join(__dirname, "api");
// The forms are small; a low cap stops large-body floods.
const MAX_BODY = Number(process.env.MAX_BODY_BYTES || 100 * 1024); // 100 KB

const MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".webp": "image/webp",
    ".txt": "text/plain; charset=utf-8"
};

// Load API handlers once at startup.
const handlers = {};
for (const file of fs.readdirSync(API_DIR)) {
    if (file.endsWith(".js") && !file.startsWith("_")) {
        handlers[file.slice(0, -3)] = require(path.join(API_DIR, file));
    }
}

// Vercel-style helpers on the response object.
function decorate(res) {
    res.status = code => {
        res.statusCode = code;
        return res;
    };
    res.json = obj => {
        if (!res.getHeader("Content-Type")) {
            res.setHeader("Content-Type", "application/json; charset=utf-8");
        }
        res.end(JSON.stringify(obj));
        return res;
    };
    res.send = body => {
        if (typeof body === "object" && !Buffer.isBuffer(body)) return res.json(body);
        res.end(body);
        return res;
    };
    return res;
}

function readBody(req) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        let size = 0;
        req.on("data", chunk => {
            size += chunk.length;
            if (size > MAX_BODY) {
                req.removeAllListeners("data");
                req.pause();
                reject(Object.assign(new Error("Payload too large"), { code: 413 }));
                return;
            }
            chunks.push(chunk);
        });
        req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
        req.on("error", reject);
    });
}

// Mirror Vercel's body parsing: JSON and urlencoded become objects, otherwise the raw string.
function parseBody(raw, contentType = "") {
    if (!raw) return undefined;
    if (contentType.includes("application/json")) {
        return JSON.parse(raw);
    }
    if (contentType.includes("application/x-www-form-urlencoded")) {
        return Object.fromEntries(new URLSearchParams(raw));
    }
    return raw;
}

function serveStatic(req, res, pathname) {
    if (req.method !== "GET" && req.method !== "HEAD") {
        res.statusCode = 405;
        return res.end();
    }

    let rel = decodeURIComponent(pathname);
    if (rel.endsWith("/")) rel += "index.html";

    const filePath = path.normalize(path.join(PUBLIC_DIR, rel));
    if (!filePath.startsWith(PUBLIC_DIR + path.sep)) {
        res.statusCode = 403;
        return res.end("Forbidden");
    }

    // Like Vercel: /login also serves /login.html if it exists.
    const candidates = [filePath];
    if (!path.extname(filePath)) candidates.push(filePath + ".html");

    for (const candidate of candidates) {
        try {
            const stat = fs.statSync(candidate);
            if (!stat.isFile()) continue;
            res.writeHead(200, {
                "Content-Type": MIME[path.extname(candidate).toLowerCase()] || "application/octet-stream",
                "Content-Length": stat.size
            });
            if (req.method === "HEAD") return res.end();
            return fs.createReadStream(candidate).pipe(res);
        } catch {
            // try next candidate
        }
    }

    res.statusCode = 404;
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.end("Not found");
}

const server = http.createServer({
    // Slow-connection (slowloris) protection: check timeouts every 2 s
    // instead of Node's default 30 s.
    connectionsCheckingInterval: 2000,
    headersTimeout: 10 * 1000,      // all headers within 10 s
    requestTimeout: 30 * 1000,      // whole request within 30 s
    keepAliveTimeout: 5 * 1000,     // close idle keep-alive connections after 5 s
    maxHeaderSize: 16 * 1024
}, async (req, res) => {
    decorate(res);
    const url = new URL(req.url, "http://localhost");
    const pathname = url.pathname;

    // Probes for Kubernetes (from the kubelet; not rate limited)
    if (pathname === "/healthz") {
        return res.status(200).json({ ok: true });
    }
    if (pathname === "/readyz") {
        try {
            await getPool().query("SELECT 1");
            return res.status(200).json({ ok: true });
        } catch (error) {
            return res.status(503).json({ ok: false, error: "database unavailable" });
        }
    }

    // Rate limiting per client IP
    const ip = clientIp(req);
    let retryAfter = hit("all", ip);
    if (!retryAfter && req.method === "POST" && pathname === "/api/login") {
        retryAfter = hit("login", ip);
    }
    if (!retryAfter && req.method === "POST" && pathname === "/api/issues") {
        retryAfter = hit("submit", ip);
    }
    if (retryAfter) {
        res.setHeader("Retry-After", String(retryAfter));
        if (pathname.startsWith("/api/")) {
            return res.status(429).json({ error: `Too many requests. Please try again in ${retryAfter} seconds.` });
        }
        res.statusCode = 429;
        res.setHeader("Content-Type", "text/plain; charset=utf-8");
        return res.end("Too many requests. Please try again shortly.");
    }

    const apiMatch = pathname.match(/^\/api\/([A-Za-z0-9-]+)\/?$/);
    if (apiMatch) {
        const handler = handlers[apiMatch[1]];
        if (!handler) {
            return res.status(404).json({ error: "Not found." });
        }

        try {
            req.query = Object.fromEntries(url.searchParams);
            const raw = await readBody(req);
            try {
                req.body = parseBody(raw, req.headers["content-type"]);
            } catch {
                return res.status(400).json({ error: "Invalid JSON body." });
            }
            await handler(req, res);
        } catch (error) {
            if (error.code === 413) {
                res.setHeader("Connection", "close");
                return res.status(413).json({ error: "Payload too large." });
            }
            console.error(error);
            if (!res.headersSent) res.status(500).json({ error: "Server error." });
        }
        return;
    }

    if (pathname.startsWith("/api/")) {
        return res.status(404).json({ error: "Not found." });
    }

    serveStatic(req, res, pathname);
});

// Connection-flood protection
server.maxHeadersCount = 100;
server.maxConnections = Number(process.env.MAX_CONNECTIONS || 2000);
limitConnectionsPerIp(server);

server.listen(PORT, () => {
    console.log(`SSTM ticketing listening on port ${PORT}`);
});

// Graceful shutdown so rolling updates don't cut requests.
function shutdown(signal) {
    console.log(`${signal} received, shutting down`);
    server.close(async () => {
        try { await getPool().end(); } catch { /* ignore */ }
        process.exit(0);
    });
    setTimeout(() => process.exit(0), 10000).unref();
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
