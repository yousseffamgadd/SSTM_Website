// In-memory, per-client-IP rate limiting for the web server.
// Each pod keeps its own counters; with 2 replicas a client can get up to
// roughly 2x these limits in total, which is fine for flood protection.

function num(name, fallback) {
    const v = Number(process.env[name]);
    return Number.isFinite(v) && v > 0 ? v : fallback;
}

const RULES = {
    // Every request (pages, CSS, images, API) per IP
    all:    { limit: num("RATE_LIMIT_PER_MIN", 120),         windowMs: 60 * 1000 },
    // Login attempts per IP (brute-force protection)
    login:  { limit: num("LOGIN_LIMIT_PER_15MIN", 10),       windowMs: 15 * 60 * 1000 },
    // Public ticket submissions per IP (spam protection)
    submit: { limit: num("SUBMIT_LIMIT_PER_10MIN", 20),      windowMs: 10 * 60 * 1000 }
};

const MAX_TRACKED = 100000;
const buckets = new Map(); // key -> { count, resetAt }

// Only trust X-Forwarded-For when a reverse proxy you control is in front.
const TRUST_PROXY = process.env.TRUST_PROXY === "true";

function clientIp(req) {
    if (TRUST_PROXY) {
        const fwd = req.headers["x-forwarded-for"];
        if (typeof fwd === "string" && fwd.trim()) return fwd.split(",")[0].trim();
    }
    return normalizeIp(req.socket.remoteAddress);
}

function normalizeIp(ip) {
    if (!ip) return "unknown";
    return ip.startsWith("::ffff:") ? ip.slice(7) : ip;
}

// Returns 0 if allowed, otherwise seconds until the client may retry.
function hit(rule, ip) {
    const cfg = RULES[rule];
    const key = rule + "|" + ip;
    const now = Date.now();
    let b = buckets.get(key);

    if (!b || now >= b.resetAt) {
        if (!b && buckets.size >= MAX_TRACKED) sweep(now, true);
        b = { count: 0, resetAt: now + cfg.windowMs };
        buckets.set(key, b);
    }

    b.count += 1;
    return b.count > cfg.limit ? Math.ceil((b.resetAt - now) / 1000) : 0;
}

function sweep(now = Date.now(), force = false) {
    for (const [key, b] of buckets) {
        if (now >= b.resetAt) buckets.delete(key);
    }
    // Under a huge spoofed-IP flood, drop everything rather than grow without bound.
    if (force && buckets.size >= MAX_TRACKED) buckets.clear();
}

setInterval(sweep, 60 * 1000).unref();

// Limits how many open connections a single IP may hold (slowloris protection).
function limitConnectionsPerIp(server) {
    const max = num("MAX_CONN_PER_IP", 50);
    const open = new Map();

    server.on("connection", socket => {
        const ip = normalizeIp(socket.remoteAddress);
        const count = (open.get(ip) || 0) + 1;

        if (count > max) {
            socket.destroy();
            return;
        }

        open.set(ip, count);
        socket.once("close", () => {
            const left = (open.get(ip) || 1) - 1;
            if (left <= 0) open.delete(ip); else open.set(ip, left);
        });
    });
}

module.exports = { RULES, clientIp, hit, limitConnectionsPerIp };
