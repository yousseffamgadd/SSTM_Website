#!/usr/bin/env bash
# Build the image, load it into the node's containerd, and deploy to Kubernetes.
# Run on the Ubuntu k8s node (control-plane/worker) from the project folder:
#   chmod +x deploy.sh && ./deploy.sh
set -euo pipefail

IMAGE="sstm-ticketing:1.0.0"
PG_IMAGE="postgres:17-alpine"
NS="sstm"
cd "$(dirname "$0")"

# 1) Secrets (generated once, kept in k8s/secrets.env — do not commit it)
if [ ! -f k8s/secrets.env ]; then
  echo ">> Generating k8s/secrets.env with random passwords"
  cat > k8s/secrets.env <<SECRETS
POSTGRES_USER=sstm
POSTGRES_DB=sstm
POSTGRES_PASSWORD=$(openssl rand -hex 24)
JWT_SECRET=$(openssl rand -hex 48)
SECRETS
  chmod 600 k8s/secrets.env
fi

# 2) Build the app image and preload both images into containerd (k8s.io namespace),
#    so pods start from local images and never need to pull from the internet.
echo ">> Building $IMAGE"
if command -v docker >/dev/null 2>&1; then
  docker build -t "$IMAGE" .
  docker pull "$PG_IMAGE"
  docker save "$IMAGE" "$PG_IMAGE" -o /tmp/sstm-images.tar
elif command -v nerdctl >/dev/null 2>&1; then
  sudo nerdctl --namespace k8s.io build -t "$IMAGE" .
  sudo nerdctl --namespace k8s.io pull "$PG_IMAGE"
elif command -v buildah >/dev/null 2>&1; then
  buildah bud -t "$IMAGE" .
  buildah push "$IMAGE" "docker-archive:/tmp/sstm-images.tar:$IMAGE"
  sudo ctr -n k8s.io images pull "docker.io/library/$PG_IMAGE"
else
  echo "No docker, nerdctl or buildah found. Install one, e.g.: sudo apt install -y docker.io" >&2
  exit 1
fi

if [ -f /tmp/sstm-images.tar ]; then
  echo ">> Importing images into containerd (k8s.io namespace)"
  sudo ctr -n k8s.io images import /tmp/sstm-images.tar
  rm -f /tmp/sstm-images.tar
fi

# 3) Deploy
# Serve the site on port 80 of this node's private IP (Oracle Cloud maps the
# public IP to it). Generated each run so it always matches this node.
PRIVATE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')
cat > k8s/05-public-ip.yaml <<PATCH
apiVersion: v1
kind: Service
metadata:
  name: sstm-web
  namespace: sstm
spec:
  externalIPs:
    - ${PRIVATE_IP}
PATCH

# Port 80 used to be a separate Service; it is now part of sstm-web.
rm -f k8s/05-public.yaml
kubectl -n "$NS" delete svc sstm-web-public --ignore-not-found

# An earlier version used a headless "postgres" Service; clusterIP can't be changed
# in place, so remove it once before applying the ClusterIP version.
if [ "$(kubectl -n "$NS" get svc postgres -o jsonpath='{.spec.clusterIP}' 2>/dev/null || true)" = "None" ]; then
  echo ">> Replacing old headless postgres Service with ClusterIP Service"
  kubectl -n "$NS" delete svc postgres
fi

# The StatefulSet's serviceName also changed (postgres -> postgres-headless) and is
# immutable. Recreate only the StatefulSet object; --cascade=orphan keeps the pod
# and its data volume, which the new StatefulSet adopts.
if [ "$(kubectl -n "$NS" get statefulset postgres -o jsonpath='{.spec.serviceName}' 2>/dev/null || true)" = "postgres" ]; then
  echo ">> Recreating postgres StatefulSet object (data is kept)"
  kubectl -n "$NS" delete statefulset postgres --cascade=orphan
fi

echo ">> Applying manifests"
kubectl apply -k k8s/

echo ">> Waiting for PostgreSQL"
kubectl -n "$NS" rollout status statefulset/postgres --timeout=180s
echo ">> Waiting for web app"
kubectl -n "$NS" rollout restart deployment/sstm-web >/dev/null
kubectl -n "$NS" rollout status deployment/sstm-web --timeout=180s

echo
echo "Done. Open: http://<public-ip>  (or http://<public-ip>:30080)"
echo "Private IP serving port 80: ${PRIVATE_IP}"
echo "Create a staff login with:"
echo "  kubectl -n $NS exec -it deploy/sstm-web -- node scripts/create-staff.js"
echo "Install the DoS firewall (once):"
echo "  sudo ./host-firewall.sh"
echo "Check everything with:"
echo "  ./verify.sh"
