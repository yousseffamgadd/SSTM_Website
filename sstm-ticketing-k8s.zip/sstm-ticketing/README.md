# SSTM Ticketing on Kubernetes (Ubuntu)

The Vercel app, running as a Kubernetes Deployment, with its own offline PostgreSQL pod inside the cluster. No Neon or any other external service is used.

```
Browser ──► public IP :80 / :30080 ──► host firewall (packet-rate limits) ──► Service sstm-web ──► Deployment sstm-web (2 pods, Node 24)
                                                          │  postgres.sstm.svc.cluster.local:5432
                                                          ▼
                            Service postgres (ClusterIP, in-cluster only)
                                                          │
                                                          ▼
                                StatefulSet postgres (1 pod, PostgreSQL 17, no internet access)
                                                          │
                                                          ▼
                                  PersistentVolume /data/sstm-postgres (on the node)
```

The database is reachable only through its ClusterIP Service, and NetworkPolicies (`k8s/04-network-policy.yaml`) allow connections to it only from the website pods. The database pod has no outbound network access, and the website pods can reach only the database and cluster DNS.

## DoS protection

There are three layers, from the outside in.

The host firewall (`sudo ./host-firewall.sh`) drops floods in the kernel's `raw` table, before Kubernetes or the app does any work. Per visitor IP, it allows 20 new connections/second (burst 50) and 300 packets/second (burst 600) to ports 80 and 30080, plus 5 pings/second. It caps new connections from all visitors together at 500/second, drops malformed TCP packets, and enables SYN cookies. The script installs a boot service, so the rules come back after a reboot. `sudo ./host-firewall.sh status` shows how many packets each rule has dropped, and `sudo ./host-firewall.sh remove` takes everything out. To change a limit, edit the values at the top of the script and run it again.

The app limits requests per visitor IP and answers `429 Too Many Requests` with a `Retry-After` header. The limits are 120 requests/minute overall, 10 login attempts per 15 minutes, and 20 ticket submissions per 10 minutes. Request bodies are capped at 100 KB and open connections at 50 per IP. Change these in the `env` section of `k8s/03-app.yaml` and run `kubectl apply -k k8s/`. Counters are kept per pod, so with 2 pods a visitor can get up to about twice these numbers.

The server also closes connections that send headers too slowly (10 s) or never finish a request (30 s), which stops slowloris-style attacks. CPU and memory limits on the pods keep an attack from starving the database or the node.

The website Service uses `externalTrafficPolicy: Local` so the app sees each visitor's real IP; without it, every visitor would appear as the node's IP and share one limit. Large distributed attacks (thousands of IPs) can still saturate the server's network link. Protection against those has to happen upstream, for example with Cloudflare in front of a domain. If you add Cloudflare or another proxy, set `TRUST_PROXY=true` in `k8s/03-app.yaml` so limits apply to the real visitor rather than the proxy.

## Deploy (on the Ubuntu k8s node)

Prerequisites: a working cluster (`kubectl get nodes` shows Ready) and Docker, nerdctl or buildah to build the image (`sudo apt install -y docker.io` is easiest).

```bash
cd sstm-ticketing
chmod +x deploy.sh
./deploy.sh
```

The script generates random DB/JWT secrets into `k8s/secrets.env`, builds the image, imports it into containerd, applies the manifests and waits for both pods.

Then create your staff login (same script as before, now run inside the pod):

```bash
kubectl -n sstm exec -it deploy/sstm-web -- node scripts/create-staff.js
```

Install the DoS firewall once with `sudo ./host-firewall.sh`. Open `http://<public-ip>` (or `http://<public-ip>:30080`), then run `./verify.sh`. It checks on the live cluster that the database is ClusterIP-only, that the website resolves and uses that ClusterIP, that a ticket submitted through the website lands in the `postgres-0` pod (the test ticket is removed afterwards), that pods other than the website can't reach the database, and that the database pod can't reach the internet.

`deploy.sh` also preloads the `postgres:17-alpine` image into containerd, so after the first deploy the pods start from local images. If the node has no internet at all, run `docker save sstm-ticketing:1.0.0 postgres:17-alpine -o images.tar` on a machine with internet and import it with `sudo ctr -n k8s.io images import images.tar` on the node.

## Manual deploy (without the script)

```bash
cp k8s/secrets.env.example k8s/secrets.env      # edit the values
docker build -t sstm-ticketing:1.0.0 .
docker pull postgres:17-alpine
docker save sstm-ticketing:1.0.0 postgres:17-alpine | sudo ctr -n k8s.io images import -
kubectl apply -k k8s/
kubectl -n sstm get pods -w
```

## Useful commands

```bash
kubectl -n sstm get pods,svc,pvc
kubectl -n sstm logs deploy/sstm-web -f
kubectl -n sstm exec -it postgres-0 -- psql -U sstm -d sstm     # SQL shell
kubectl -n sstm exec postgres-0 -- pg_dump -U sstm sstm > backup.sql
```

To look at the data from your own PC without exposing the database, use a temporary tunnel: `kubectl -n sstm port-forward svc/postgres 5432:5432` (it closes when you stop the command).

## What changed from the Vercel version

`server.js` (new) replaces the Vercel runtime: it routes `/api/<name>` to `api/<name>.js`, parses JSON bodies, provides `res.status().json()`, serves `public/`, and adds `/healthz` and `/readyz` for Kubernetes probes. The API handlers and frontend are unchanged apart from two settings. `api/_db.js` connects without TLS, since traffic to the in-cluster database never leaves the cluster network. In `api/_auth.js`, the cookie's `Secure` flag is controlled by `COOKIE_SECURE`; it is `false` in the manifest because NodePort is plain HTTP, and browsers silently drop `Secure` cookies over HTTP, which would make login appear to do nothing. Set it to `"true"` once HTTPS (Ingress + TLS) is in front.

The schema (`k8s/schema.sql`, also used by `npm run init-db`) now matches what `api/issues.js` writes: it adds the `category` and `details` (JSONB) columns and makes `issue_description` and `gateway_number` nullable, which Site Visit and Installation requests need. The default status is `Opened` so new tickets count correctly on the dashboard.

## Notes

Port 80: `deploy.sh` writes `k8s/05-public-ip.yaml` with the node's private IP, and the website answers on port 80 there. Oracle Cloud forwards the public IP to that private IP. On Oracle you also need ingress rules for TCP 80 and 30080 in the VCN Security List (`host-firewall.sh` opens them in the server's own firewall). If you apply manifests by hand, create that file from `k8s/05-public-ip.yaml.example` first.

NetworkPolicy needs a CNI that enforces it, such as Calico or Cilium. Flannel, a common kubeadm choice, silently ignores the policies: the database is still not exposed outside the cluster (ClusterIP), but other pods could reach it and it could reach the internet. `verify.sh` reports this as a warning. Check with `kubectl get pods -n kube-system` (look for `calico-` or `cilium-`).

Upgrading from the first version: `deploy.sh` replaces the old headless `postgres` Service and recreates the StatefulSet object with `--cascade=orphan`, so the running database pod and its data are kept.

Storage: a fresh kubeadm cluster has no StorageClass, so `01-postgres-storage.yaml` uses a hostPath volume at `/data/sstm-postgres` on the node. That is right for a single-node cluster. On multiple nodes, use a real StorageClass (local-path-provisioner, Longhorn, NFS): remove that file from `kustomization.yaml` and set `storageClassName` in `02-postgres.yaml`.

The image is loaded into the local node's containerd. On a multi-node cluster, push it to a registry instead and update `image:` in `03-app.yaml`.

`POSTGRES_PASSWORD` only takes effect the first time the database is created. To change it later, run `ALTER USER sstm PASSWORD '...'` in psql and update `k8s/secrets.env` to match.
