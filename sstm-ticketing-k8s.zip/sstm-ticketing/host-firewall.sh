#!/usr/bin/env bash
# Packet-rate DoS protection for the SSTM website, applied on the k8s node.
#
#   sudo ./host-firewall.sh            install + apply (also re-applied at every boot)
#   sudo ./host-firewall.sh status     show rules and how many packets were dropped
#   sudo ./host-firewall.sh remove     remove the rules and the boot service
#
# Rules live in the iptables "raw" table, which runs before connection tracking,
# kube-proxy and Calico, so flood packets are dropped as early as possible.
# Only traffic arriving on the public interface to the website ports is affected;
# pod-to-pod and SSH traffic are untouched.
set -euo pipefail

# ---- Limits (per source IP unless noted) -----------------------------------
WEB_PORTS="80,30080"
SYN_PER_IP="20/second";     SYN_PER_IP_BURST=50     # new TCP connections per IP
SYN_TOTAL="500/second";     SYN_TOTAL_BURST=1000    # new connections, all IPs together
PKT_PER_IP="300/second";    PKT_PER_IP_BURST=600    # all packets per IP to the website
ICMP_PER_IP="5/second";     ICMP_PER_IP_BURST=10    # pings per IP
# -----------------------------------------------------------------------------

CHAIN="SSTM-DOS"
SELF="/usr/local/sbin/sstm-host-firewall.sh"
UNIT="/etc/systemd/system/sstm-host-firewall.service"
SYSCTL="/etc/sysctl.d/90-sstm-dos.conf"

[ "$(id -u)" -eq 0 ] || { echo "Run with sudo: sudo $0 $*" >&2; exit 1; }

IFACE=$(ip -4 route show default | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')
[ -n "$IFACE" ] || { echo "Could not find the public network interface" >&2; exit 1; }

ipt() { iptables -w 5 "$@"; }

apply_rules() {
  # Kernel hardening against SYN floods
  cat > "$SYSCTL" <<EOF
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_max_syn_backlog = 4096
net.ipv4.tcp_synack_retries = 2
net.ipv4.icmp_echo_ignore_broadcasts = 1
EOF
  sysctl -q -p "$SYSCTL"

  # (Re)build our chain from scratch so the script is safe to run repeatedly
  ipt -t raw -N "$CHAIN" 2>/dev/null || ipt -t raw -F "$CHAIN"

  # Malformed TCP flag combinations (scans / crafted floods)
  ipt -t raw -A "$CHAIN" -p tcp --tcp-flags ALL NONE -j DROP
  ipt -t raw -A "$CHAIN" -p tcp --tcp-flags ALL ALL -j DROP
  ipt -t raw -A "$CHAIN" -p tcp --tcp-flags SYN,FIN SYN,FIN -j DROP
  ipt -t raw -A "$CHAIN" -p tcp --tcp-flags SYN,RST SYN,RST -j DROP

  # New connections to the website: per IP, then overall
  ipt -t raw -A "$CHAIN" -p tcp -m multiport --dports "$WEB_PORTS" --syn \
      -m hashlimit --hashlimit-name sstm_syn --hashlimit-mode srcip \
      --hashlimit-above "$SYN_PER_IP" --hashlimit-burst "$SYN_PER_IP_BURST" \
      --hashlimit-htable-size 32768 --hashlimit-htable-max 131072 -j DROP
  ipt -t raw -A "$CHAIN" -p tcp -m multiport --dports "$WEB_PORTS" --syn \
      -m hashlimit --hashlimit-name sstm_syn_all \
      --hashlimit-above "$SYN_TOTAL" --hashlimit-burst "$SYN_TOTAL_BURST" -j DROP

  # Packet rate to the website per IP
  ipt -t raw -A "$CHAIN" -p tcp -m multiport --dports "$WEB_PORTS" \
      -m hashlimit --hashlimit-name sstm_pps --hashlimit-mode srcip \
      --hashlimit-above "$PKT_PER_IP" --hashlimit-burst "$PKT_PER_IP_BURST" \
      --hashlimit-htable-size 32768 --hashlimit-htable-max 131072 -j DROP

  # Ping flood per IP
  ipt -t raw -A "$CHAIN" -p icmp --icmp-type echo-request \
      -m hashlimit --hashlimit-name sstm_icmp --hashlimit-mode srcip \
      --hashlimit-above "$ICMP_PER_IP" --hashlimit-burst "$ICMP_PER_IP_BURST" -j DROP

  ipt -t raw -A "$CHAIN" -j RETURN

  # Hook the chain in for packets arriving on the public interface
  ipt -t raw -C PREROUTING -i "$IFACE" -j "$CHAIN" 2>/dev/null \
    || ipt -t raw -I PREROUTING 1 -i "$IFACE" -j "$CHAIN"

  # Make sure the website ports are open in the host firewall (Oracle images block them)
  for p in 80 30080; do
    ipt -C INPUT -p tcp --dport "$p" -j ACCEPT 2>/dev/null \
      || ipt -I INPUT -p tcp --dport "$p" -j ACCEPT
  done

  echo "DoS rules active on interface $IFACE for ports $WEB_PORTS"
}

install_boot_service() {
  if [ "$(readlink -f "$0")" != "$SELF" ]; then
    install -m 0755 "$0" "$SELF"
  fi
  cat > "$UNIT" <<EOF
[Unit]
Description=SSTM website DoS packet-rate limits
After=network-online.target netfilter-persistent.service
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=$SELF apply
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable sstm-host-firewall.service >/dev/null 2>&1
  echo "Boot service installed: rules are re-applied automatically after reboot"
}

remove_rules() {
  while ipt -t raw -C PREROUTING -i "$IFACE" -j "$CHAIN" 2>/dev/null; do
    ipt -t raw -D PREROUTING -i "$IFACE" -j "$CHAIN"
  done
  ipt -t raw -F "$CHAIN" 2>/dev/null || true
  ipt -t raw -X "$CHAIN" 2>/dev/null || true
  systemctl disable --now sstm-host-firewall.service >/dev/null 2>&1 || true
  rm -f "$UNIT" "$SELF" "$SYSCTL"
  systemctl daemon-reload
  echo "DoS rules and boot service removed (ports 80/30080 stay open)"
}

status() {
  echo "Interface: $IFACE"
  echo "Dropped packets per rule (pkts column):"
  ipt -t raw -L "$CHAIN" -v -n --line-numbers 2>/dev/null || echo "  (rules not installed)"
  echo
  systemctl is-enabled sstm-host-firewall.service 2>/dev/null | sed 's/^/Boot service: /' || true
}

case "${1:-install}" in
  install) apply_rules; install_boot_service ;;
  apply)   apply_rules ;;
  status)  status ;;
  remove)  remove_rules ;;
  *) echo "Usage: sudo $0 [install|status|remove]" >&2; exit 1 ;;
esac
