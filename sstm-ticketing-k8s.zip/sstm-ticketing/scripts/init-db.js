require("dotenv").config();

const fs = require("fs");
const path = require("path");
const { getPool } = require("../api/_db");

async function main() {
    const db = getPool();
    const sql = fs.readFileSync(path.join(__dirname, "..", "k8s", "schema.sql"), "utf8");
    await db.query(sql);
    console.log("Database tables created/updated.");
    await db.end();
}

main().catch(error => {
    console.error(error);
    process.exit(1);
});
