const readline =
    require("readline");

const bcrypt =
    require("bcryptjs");

const { getPool } =
    require("../api/_db");


const rl =
    readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });


function ask(question) {

    return new Promise(resolve => {

        rl.question(
            question,
            resolve
        );

    });
}


async function main() {

    const username =
        (
            await ask("Username: ")
        ).trim();


    const password =
        await ask("Password: ");


    const name =
        (
            await ask("Staff name: ")
        ).trim();


    if (
        !username ||
        !password ||
        !name
    ) {

        throw new Error(
            "Username, password and name are required."
        );
    }


    const hash =
        await bcrypt.hash(
            password,
            12
        );


    const db =
        getPool();


    await db.query(

        `INSERT INTO staff
            (
                username,
                password_hash,
                name
            )

         VALUES
            ($1, $2, $3)

         ON CONFLICT (username)

         DO UPDATE SET
            password_hash =
                EXCLUDED.password_hash,

            name =
                EXCLUDED.name`,

        [
            username,
            hash,
            name
        ]
    );


    console.log(
        `Staff user "${username}" created/updated.`
    );


    await db.end();

    rl.close();
}


main().catch(error => {

    console.error(
        error.message
    );

    rl.close();

    process.exit(1);

});