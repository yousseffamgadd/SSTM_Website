
const categorySelect = document.getElementById("category");
const maintenanceForm = document.getElementById("maintenanceForm");
const siteVisitForm = document.getElementById("siteVisitForm");
const installationForm = document.getElementById("installationForm");
const message = document.getElementById("message");

const gatewayList = document.getElementById("gatewayList");
const addGatewayButton = document.getElementById("addGateway");

function addGateway() {
    const row = document.createElement("div");
    row.className = "gateway-row";

    row.innerHTML = `
        <input
            name="gateway_numbers"
            placeholder="Gateway number"
            required
        >
        <button
            type="button"
            class="remove-gateway"
            aria-label="Remove gateway"
        >×</button>
    `;

    row.querySelector(".remove-gateway")
        .addEventListener("click", () => {
            if (gatewayList.children.length > 1) {
                row.remove();
            }
        });

    gatewayList.appendChild(row);
}

function removeGateway(button) {
    if (gatewayList.children.length > 1) {
        button.closest(".gateway-row").remove();
    }
}

addGatewayButton.addEventListener("click", addGateway);
function showCategory() {
    maintenanceForm.hidden = categorySelect.value !== "Maintenance";
    siteVisitForm.hidden = categorySelect.value !== "Site Visit";
    installationForm.hidden = categorySelect.value !== "Installation";

    message.textContent = "";
}

categorySelect.addEventListener("change", showCategory);

function getFormData(form) {
    return Object.fromEntries(new FormData(form).entries());
}

async function submitRequest(form, category) {
    message.textContent = "Submitting...";
    message.className = "message";

    const data = getFormData(form);

if (category === "Maintenance") {
    data.gateway_numbers = [
        ...form.querySelectorAll(
            '[name="gateway_numbers"]'
        )
    ].map(input => input.value.trim());
}

    try {
        const response = await fetch("/api/issues", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                category,
                ...data
            })
        });

        const responseText = await response.text();

        let result;

        try {
            result = JSON.parse(responseText);
        } catch (error) {
            console.error("Non-JSON response from server:", responseText);

            throw new Error(
                "Server returned an invalid response. Check the backend logs."
            );
        }

        if (!response.ok) {
            throw new Error(result.error || "Submission failed.");
        }
        message.textContent =
            `Request submitted successfully. Ticket #${result.issueId}`;

        message.className = "message success";
        form.reset();

    } catch (error) {
        message.textContent = error.message;
        message.className = "message error";
    }
}

maintenanceForm.addEventListener("submit", function(event) {
    event.preventDefault();
    submitRequest(maintenanceForm, "Maintenance");
});

siteVisitForm.addEventListener("submit", function(event) {
    event.preventDefault();
    submitRequest(siteVisitForm, "Site Visit");
});

installationForm.addEventListener("submit", function(event) {
    event.preventDefault();
    submitRequest(installationForm, "Installation");
});

showCategory();