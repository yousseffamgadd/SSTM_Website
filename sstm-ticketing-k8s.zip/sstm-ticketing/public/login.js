const form =
    document.getElementById("loginForm");

const message =
    document.getElementById("message");


form.addEventListener(
    "submit",
    async function(event) {

        event.preventDefault();

        message.textContent =
            "Signing in...";

        message.className =
            "message";


        try {

            const response =
                await fetch(
                    "/api/login",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({

                            username:
                                document.getElementById(
                                    "username"
                                ).value,

                            password:
                                document.getElementById(
                                    "password"
                                ).value
                        })
                    }
                );


            const result =
                await response.json();


            if (!response.ok) {

                throw new Error(
                    result.error ||
                    "Login failed."
                );
            }


            window.location.href =
                "/dashboard.html";


        } catch (error) {

            message.textContent =
                error.message;

            message.className =
                "message error";
        }

    }
);