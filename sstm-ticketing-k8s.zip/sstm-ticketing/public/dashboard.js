const body =
    document.getElementById("issuesBody");

const message =
    document.getElementById("message");


function escapeHtml(value) {

    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
async function closeIssue(issueId) {

    const confirmed = confirm(
        `Are you sure you want to close and permanently delete issue #${issueId}?`
    );

    if (!confirmed) {
        return;
    }

    try {

        const response = await fetch("/api/issues", {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                id: issueId
            })
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(
                result.error || "Could not delete issue."
            );
        }

        await loadDashboard();

    } catch (error) {

        message.textContent = error.message;
        message.className = "message error";
    }
}


const maintenanceBody = document.getElementById("maintenanceBody");
const installationBody = document.getElementById("installationBody");
const siteVisitBody = document.getElementById("siteVisitBody");

const statuses = [
    "Opened",
    "In progress",
    "Testing",
    "Visiting"
];

function statusDropdown(issue) {
    const currentStatus = statuses.includes(issue.status)
        ? issue.status
        : "Opened";

    return `
        <select class="status-select"
            data-issue-id="${escapeHtml(issue.id)}"
            onchange="updateIssueStatus(this)">
            ${statuses.map(status => `
                <option value="${escapeHtml(status)}"
                    ${status === currentStatus ? "selected" : ""}>
                    ${escapeHtml(status)}
                </option>
            `).join("")}
        </select>
    `;
}

function actionButton(issue) {
    return `
        <button class="close-button"
            onclick="closeIssue(${Number(issue.id)})">
            Close & Delete
        </button>
    `;
}

function maintenanceRow(issue) {
    const d = issue.details || {};

    const gateways = Array.isArray(d.gateway_numbers)
        ? d.gateway_numbers.join(", ")
        : issue.gateway_number || "—";

    return `
        <tr>
            <td>${escapeHtml(issue.company || d.company || "—")}</td>
            <td>#${escapeHtml(issue.id)}</td>
            <td>${escapeHtml(gateways)}</td>
            <td>${escapeHtml(issue.name || d.name || "—")}</td>
            <td>${escapeHtml(issue.phone || d.phone || "—")}</td>
            <td class="issue-cell">${escapeHtml(
                d.issue_description || issue.issue_description || "—"
            )}</td>
            <td>${statusDropdown(issue)}</td>
            <td>${actionButton(issue)}</td>
        </tr>
    `;
}

function installationRow(issue) {
    const d = issue.details || {};

    return `
        <tr>
            <td>${escapeHtml(issue.company || "—")}</td>
            <td>#${escapeHtml(issue.id)}</td>
            <td>${escapeHtml(issue.name || "—")}</td>
            <td>${escapeHtml(issue.phone || "—")}</td>
            <td>${escapeHtml(d.gateway_count ?? "—")}</td>
            <td>${escapeHtml(d.sensor_count ?? "—")}</td>
            <td>${escapeHtml(d.sensor_type || "—")}</td>
            <td>${escapeHtml(d.battery_based || "—")}</td>
            <td class="issue-cell">${escapeHtml(d.additional_info || "—")}</td>
            <td>${statusDropdown(issue)}</td>
            <td>${actionButton(issue)}</td>
        </tr>
    `;
}

function siteVisitRow(issue) {
    const d = issue.details || {};

    return `
        <tr>
            <td>${escapeHtml(issue.company || d.company || "—")}</td>
            <td>#${escapeHtml(issue.id)}</td>
            <td>${escapeHtml(issue.name || d.name || "—")}</td>
            <td>${escapeHtml(issue.phone || d.contact_number || "—")}</td>
            <td>${escapeHtml(d.expected_area || "—")}</td>
            <td class="issue-cell">${escapeHtml(d.additional_info || "—")}</td>
            <td>${statusDropdown(issue)}</td>
            <td>${actionButton(issue)}</td>
        </tr>
    `;
}

async function loadDashboard() {
    message.textContent = "Loading requests...";
    message.className = "message";

    try {
        const meResponse = await fetch("/api/me");

        if (!meResponse.ok) {
            window.location.href = "/login.html";
            return;
        }

        const me = await meResponse.json();
        document.getElementById("staffName").textContent = `(${me.name})`;

        const response = await fetch("/api/issues");

        if (!response.ok) {
            throw new Error("Could not load requests.");
        }

        const result = await response.json();
        const issues = result.issues || [];
        updateTicketStats(issues);
        const maintenance = issues.filter(i =>
            !i.category || i.category === "Maintenance"
        );

        const installations = issues.filter(i =>
            i.category === "Installation"
        );

        const siteVisits = issues.filter(i =>
            i.category === "Site Visit"
        );

        maintenanceBody.innerHTML =
            maintenance.map(maintenanceRow).join("");

        installationBody.innerHTML =
            installations.map(installationRow).join("");

        siteVisitBody.innerHTML =
            siteVisits.map(siteVisitRow).join("");

        message.textContent =
            `${issues.length} total request(s) loaded.`;
        message.className = "message success";

    } catch (error) {
        message.textContent = error.message;
        message.className = "message error";
    }
}

document.getElementById("refreshButton").addEventListener(
    "click",
    loadDashboard
);




document
    .getElementById("refreshButton")
    .addEventListener(
        "click",
        loadDashboard
    );


document
    .getElementById("logoutButton")
    .addEventListener(
        "click",
        async function() {

            await fetch(
                "/api/logout",
                {
                    method: "POST"
                }
            );

            window.location.href =
                "/login.html";
        }
    );



async function updateIssueStatus(select) {
    const issueId = Number(select.dataset.issueId);
    const newStatus = select.value;

    select.disabled = true;
    message.textContent = "Updating status...";
    message.className = "message";

    try {
        const response = await fetch("/api/issues", {
            method: "PATCH",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                id: issueId,
                status: newStatus
            })
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(
                result.error || "Could not update status."
            );
        }

        message.textContent =
            `Issue #${issueId} updated to ${newStatus}.`;
        message.className = "message success";

    } catch (error) {
        message.textContent = error.message;
        message.className = "message error";

        // Reload to restore the actual status from the database
        await loadDashboard();

    } finally {
        select.disabled = false;
    }
}

function updateTicketStats(issues) {
  // Total tickets
  document.getElementById("totalTickets").textContent =
    issues.length;

  // Tickets by status
  document.getElementById("inProgressTickets").textContent =
    issues.filter(issue =>
      issue.status?.toLowerCase() === "in progress"
    ).length;

  document.getElementById("openedTickets").textContent =
    issues.filter(issue =>
      issue.status?.toLowerCase() === "opened"
    ).length;

  document.getElementById("testingTickets").textContent =
    issues.filter(issue =>
      issue.status?.toLowerCase() === "testing"
    ).length;

  // Visiting = Site Visit category
  document.getElementById("visitingTickets").textContent =
    issues.filter(issue =>
      issue.status?.toLowerCase() === "visiting"
    ).length;

  // Count unique companies (ignore empty company names)
  const companies = new Set(
    issues
      .map(issue => issue.company?.trim().toLowerCase())
      .filter(Boolean)
  );

  document.getElementById("totalCompanies").textContent =
    companies.size;
}

loadDashboard();