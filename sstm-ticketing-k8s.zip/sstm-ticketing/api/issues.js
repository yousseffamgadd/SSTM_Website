
const { getPool } = require("./_db");
const { requireStaff } = require("./_auth");

module.exports = async function handler(req, res) {
    const db = getPool();

    // SUBMIT A REQUEST
    if (req.method === "POST") {
        const { category, ...data } = req.body || {};

        let details = {};
        let name = null;
        let company = null;
        let phone = null;
        let gatewayNumber = null;
        let issueDescription = null;

        if (category === "Maintenance") {
    const gateways = Array.isArray(data.gateway_numbers)
        ? data.gateway_numbers
            .filter(g => typeof g === "string")
            .map(g => g.trim())
        : [];

    if (
        typeof data.issue_description !== "string" ||
        !data.issue_description.trim() ||
        typeof data.company !== "string" ||
        !data.company.trim() ||
        typeof data.name !== "string" ||
        !data.name.trim() ||
        typeof data.phone !== "string" ||
        !data.phone.trim() ||
        gateways.length === 0 ||
        gateways.some(g => !g)
    ) {
        return res.status(400).json({
            error: "Please complete all required maintenance fields."
        });
    }

    issueDescription = data.issue_description.trim();
    company = data.company.trim();
    name = data.name.trim();
    phone = data.phone.trim();

    // Store all gateway numbers in the existing DB column
    gatewayNumber = gateways.join(", ");

    // Store structured details, including the full gateway list
    details = {
        issue_description: issueDescription,
        company,
        gateway_numbers: gateways,
        name,
        phone
    };

        } else if (category === "Site Visit") {
            const required = ["contact_number", "name", "company"];

            if (!required.every(key =>
                typeof data[key] === "string" && data[key].trim()
            )) {
                return res.status(400).json({
                    error: "Contact number, name and company are required."
                });
            }

            name = data.name.trim();
            company = data.company.trim();
            phone = data.contact_number.trim();

            details = {
                contact_number: phone,
                name,
                company,
                expected_area: (data.expected_area || "").trim(),
                additional_info: (data.additional_info || "").trim()
            };

        } else if (category === "Installation") {
             

            name = data.name.trim();
            company = data.company.trim();
            phone = data.contact_number.trim();
            const gatewayCount = Number(data.gateway_count);
            const sensorCount = Number(data.sensor_count);

            if (
                !Number.isInteger(gatewayCount) || gatewayCount < 1 ||
                !Number.isInteger(sensorCount) || sensorCount < 0 ||
                !["Wired", "Wireless"].includes(data.sensor_type) ||
                !["Yes", "No"].includes(data.battery_based)
            ) {
                return res.status(400).json({
                    error: "Please complete the installation fields correctly."
                });
            }

            details = {
                contact_number: phone,
                company,
                name,
                gateway_count: gatewayCount,
                sensor_count: sensorCount,
                sensor_type: data.sensor_type,
                battery_based: data.battery_based,
                additional_info: (data.additional_info || "").trim()
            };

        } else {
            return res.status(400).json({
                error: "Invalid request category."
            });
        }

        try {
            const result = await db.query(
                `INSERT INTO issues
                    (category, issue_description, company,
                     gateway_number, name, phone, details)
                 VALUES ($1, $2, $3, $4, $5, $6, $7)
                 RETURNING id`,
                [
                    category,
                    issueDescription,
                    company,
                    gatewayNumber,
                    name,
                    phone,
                    JSON.stringify(details)
                ]
            );

            return res.status(201).json({
                issueId: result.rows[0].id
            });

        } catch (error) {
            console.error(error);

            return res.status(500).json({
                error: "Database error."
            });
        }
    }

    // STAFF VIEWS REQUESTS
    if (req.method === "GET") {
        const staff = requireStaff(req, res);
        if (!staff) return;

        try {
            const result = await db.query(
                `SELECT *
                 FROM issues
                 ORDER BY created_at DESC`
            );

            return res.status(200).json({
                issues: result.rows
            });

        } catch (error) {
            console.error(error);

            return res.status(500).json({
                error: "Database error."
            });
        }
    }

    // STAFF UPDATES ISSUE STATUS
if (req.method === "PATCH") {
    const staff = requireStaff(req, res);
    if (!staff) return;

    const { id, status } = req.body || {};

    const allowedStatuses = [
        "Opened",
        "In progress",
        "Testing",
        "Visiting"
    ];

    const issueId = Number(id);

    if (
        !Number.isInteger(issueId) ||
        issueId < 1 ||
        !allowedStatuses.includes(status)
    ) {
        return res.status(400).json({
            error: "Invalid issue ID or status."
        });
    }

    try {
        const result = await db.query(
            `UPDATE issues
             SET status = $1
             WHERE id = $2
             RETURNING id, status`,
            [status, issueId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                error: "Issue not found."
            });
        }

        return res.status(200).json({
            issue: result.rows[0]
        });

    } catch (error) {
        console.error(error);

        return res.status(500).json({
            error: "Database error."
        });
    }
}

    // STAFF PERMANENTLY DELETES A REQUEST
    if (req.method === "DELETE") {
        const staff = requireStaff(req, res);
        if (!staff) return;

        const id = Number(req.body?.id);

        if (!Number.isInteger(id) || id < 1) {
            return res.status(400).json({
                error: "Valid issue ID is required."
            });
        }

        try {
            const result = await db.query(
                `DELETE FROM issues
                 WHERE id = $1
                 RETURNING id`,
                [id]
            );

            if (result.rows.length === 0) {
                return res.status(404).json({
                    error: "Issue not found."
                });
            }

            return res.status(200).json({
                ok: true,
                message: "Issue deleted."
            });

        } catch (error) {
            console.error(error);

            return res.status(500).json({
                error: "Database error."
            });
        }
    }

    res.setHeader("Allow", "GET, POST, PATCH, DELETE");

    return res.status(405).json({
        error: "Method not allowed."
    });
};