const jwt = require("jsonwebtoken");

const COOKIE_NAME = "sstm_session";

// Secure cookies are dropped by browsers over plain HTTP. Set COOKIE_SECURE=false
// when serving over http (e.g. NodePort); keep true behind HTTPS/Ingress TLS.
const SECURE = process.env.COOKIE_SECURE === "false" ? "" : " Secure;";

function signStaff(staff) {
    return jwt.sign(
        {
            id: staff.id,
            username: staff.username,
            name: staff.name
        },
        process.env.JWT_SECRET,
        {
            expiresIn: "8h"
        }
    );
}

function getToken(req) {
    const cookieHeader = req.headers.cookie || "";

    const cookie = cookieHeader
        .split(";")
        .map(v => v.trim())
        .find(v => v.startsWith(`${COOKIE_NAME}=`));

    if (!cookie) {
        return null;
    }

    return decodeURIComponent(cookie.split("=")[1]);
}

function requireStaff(req, res) {
    const token = getToken(req);

    if (!token) {
        res.status(401).json({
            error: "Authentication required."
        });

        return null;
    }

    try {
        return jwt.verify(token, process.env.JWT_SECRET);
    } catch (error) {
        res.status(401).json({
            error: "Invalid or expired session."
        });

        return null;
    }
}

function setSession(res, token) {
    res.setHeader(
        "Set-Cookie",
        `${COOKIE_NAME}=${encodeURIComponent(token)}; HttpOnly;${SECURE} SameSite=Lax; Path=/; Max-Age=28800`
    );
}

function clearSession(res) {
    res.setHeader(
        "Set-Cookie",
        `${COOKIE_NAME}=; HttpOnly;${SECURE} SameSite=Lax; Path=/; Max-Age=0`
    );
}

module.exports = {
    signStaff,
    requireStaff,
    setSession,
    clearSession
};