const bcrypt = require("bcryptjs");
const { getPool } = require("./_db");
const {
    signStaff,
    setSession
} = require("./_auth");

module.exports = async function handler(req, res) {

    if (req.method !== "POST") {
        res.setHeader("Allow", "POST");

        return res.status(405).json({
            error: "Method not allowed."
        });
    }

    const {
        username,
        password
    } = req.body || {};

    if (
        typeof username !== "string" ||
        typeof password !== "string"
    ) {
        return res.status(400).json({
            error: "Username and password are required."
        });
    }

    try {

        const db = getPool();

        const result = await db.query(
            `SELECT
                id,
                username,
                password_hash,
                name
             FROM staff
             WHERE username = $1
             LIMIT 1`,
            [username.trim()]
        );

        if (result.rows.length === 0) {
            return res.status(401).json({
                error: "Invalid username or password."
            });
        }

        const staff = result.rows[0];

        const validPassword = await bcrypt.compare(
            password,
            staff.password_hash
        );

        if (!validPassword) {
            return res.status(401).json({
                error: "Invalid username or password."
            });
        }

        const token = signStaff(staff);

        setSession(res, token);

        return res.status(200).json({
            ok: true
        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({
            error: "Login error."
        });
    }
};