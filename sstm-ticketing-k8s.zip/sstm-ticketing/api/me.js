const { requireStaff } = require("./_auth");

module.exports = async function handler(req, res) {

    if (req.method !== "GET") {
        res.setHeader("Allow", "GET");

        return res.status(405).json({
            error: "Method not allowed."
        });
    }

    const staff = requireStaff(req, res);

    if (!staff) {
        return;
    }

    return res.status(200).json({
        id: staff.id,
        username: staff.username,
        name: staff.name
    });
};