require("dotenv").config();

const { Pool } = require("pg");

let pool;

// Connects to the in-cluster PostgreSQL pod through its ClusterIP Service
// (DATABASE_URL = postgresql://user:pass@postgres:5432/db). Traffic never
// leaves the cluster network, so no TLS is used.
function getPool() {
    if (!pool) {
        pool = new Pool({
            connectionString: process.env.DATABASE_URL,
            ssl: false,
            max: Number(process.env.DB_POOL_MAX || 5)
        });
    }

    return pool;
}

module.exports = {
    getPool
};
