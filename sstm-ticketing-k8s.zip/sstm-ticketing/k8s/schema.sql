-- SSTM ticketing schema (matches api/issues.js, api/login.js)
CREATE TABLE IF NOT EXISTS staff (
    id            SERIAL PRIMARY KEY,
    username      VARCHAR(100) UNIQUE NOT NULL,
    password_hash TEXT         NOT NULL,
    name          VARCHAR(200) NOT NULL,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS issues (
    id                SERIAL PRIMARY KEY,
    category          VARCHAR(50),
    issue_description TEXT,
    company           VARCHAR(200) NOT NULL,
    gateway_number    VARCHAR(500),
    name              VARCHAR(200) NOT NULL,
    phone             VARCHAR(50)  NOT NULL,
    details           JSONB        NOT NULL DEFAULT '{}'::jsonb,
    status            VARCHAR(30)  NOT NULL DEFAULT 'Opened',
    created_at        TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Upgrade path for databases created by the original init-db.js
ALTER TABLE issues ADD COLUMN IF NOT EXISTS category VARCHAR(50);
ALTER TABLE issues ADD COLUMN IF NOT EXISTS details JSONB NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE issues ALTER COLUMN issue_description DROP NOT NULL;
ALTER TABLE issues ALTER COLUMN gateway_number DROP NOT NULL;
ALTER TABLE issues ALTER COLUMN gateway_number TYPE VARCHAR(500);

CREATE INDEX IF NOT EXISTS issues_created_at_idx ON issues (created_at DESC);
