#!/usr/bin/env bash
# Checks, on the live cluster, that the CoolTeck website is running correctly:
#   1. pods are ready
#   2. it is served on port 8080 (and NodePort 30081) with visitor IPs preserved
#   3. the Support button points to the SSTM ticketing site on its port, and that site answers
#   4. page-generator source files are not public
#   5. the pods have no outbound network access
#   6. the DoS firewall is installed
set -uo pipefail
NS="coolteck"
PASS=0; FAIL=0; WARN=0
ok()   { echo "  [PASS] $*"; PASS=$((PASS+1)); }
bad()  { echo "  [FAIL] $*"; FAIL=$((FAIL+1)); }
warn() { echo "  [WARN] $*"; WARN=$((WARN+1)); }

echo "1) Pods"
ready=$(kubectl -n $NS get pods -l app=coolteck-web -o jsonpath='{range .items[*]}{.status.containerStatuses[0].ready}{" "}{end}')
if [ -n "$ready" ] && ! echo "$ready" | grep -q false; then ok "coolteck-web ready ($ready)"; else bad "coolteck-web not ready: '$ready'"; fi

echo "2) Public access"
svc=$(kubectl -n $NS get svc coolteck-web -o jsonpath='{.spec.ports[0].port}/{.spec.ports[0].nodePort}' 2>/dev/null)
eip=$(kubectl -n $NS get svc coolteck-web -o jsonpath='{.spec.externalIPs[0]}' 2>/dev/null)
etp=$(kubectl -n $NS get svc coolteck-web -o jsonpath='{.spec.externalTrafficPolicy}' 2>/dev/null)
[ "$svc" = "8080/30081" ] && ok "service ports 8080 and 30081" || bad "service ports are '$svc'"
[ -n "$eip" ] && ok "served on port 8080 at $eip (Oracle maps the public IP here)" || bad "no externalIPs set (port 8080 not served)"
[ "$etp" = "Local" ] && ok "visitor IPs preserved (per-IP limits work)" || bad "externalTrafficPolicy is '$etp'"
code=$(curl -s -o /dev/null -m 5 -w '%{http_code}' "http://${eip:-127.0.0.1}:8080/" 2>/dev/null)
[ "$code" = "200" ] && ok "home page answers on http://$eip:8080/" || bad "home page on port 8080 returned '$code'"

echo "3) Support button"
page=$(kubectl -n $NS exec deploy/coolteck-web -- wget -qO- --header "Host: ${eip:-node}" http://127.0.0.1:8080/index.html 2>/dev/null)
link=$(echo "$page" | grep -oE '<a href="[^"]*"[^>]*>Support<' | head -1 | sed -E 's/<a href="([^"]*)".*/\1/')
if echo "$page" | grep -q "vercel"; then
  bad "Support button still points to Vercel"
elif [ -n "$link" ]; then
  ok "Support button points to $link"
  tcode=$(curl -s -o /dev/null -m 5 -w '%{http_code}' "$link" 2>/dev/null)
  if [ "$tcode" = "200" ]; then ok "ticketing site answers at $link"
  else warn "ticketing site at $link returned '$tcode': is the SSTM ticketing site deployed?"; fi
else
  bad "could not read the Support button from the home page"
fi

echo "4) Private files"
scode=$(kubectl -n $NS exec deploy/coolteck-web -- wget -qS -O /dev/null http://127.0.0.1:8080/source/build.py 2>&1 | grep -oE "HTTP/1.1 [0-9]+" | tail -1)
[ "$scode" != "HTTP/1.1 200" ] && ok "page-generator source files not public" || bad "/source/ is publicly readable"

echo "5) No outbound access"
if kubectl -n $NS exec deploy/coolteck-web -- wget -q -T 5 -O /dev/null http://1.1.1.1 >/dev/null 2>&1; then
  warn "coolteck-web CAN reach the internet: your CNI is not enforcing NetworkPolicy"
else
  ok "coolteck-web has no outbound access"
fi

echo "6) DoS protection"
lim=$(kubectl -n $NS exec deploy/coolteck-web -- printenv RATE_PER_SEC 2>/dev/null)
[ -n "$lim" ] && ok "nginx rate limit active ($lim requests/second per IP)" || bad "rate limit settings missing"
if sudo -n true 2>/dev/null; then
  if sudo iptables -t raw -S COOLTECK-DOS >/dev/null 2>&1; then ok "host packet-rate firewall active (sudo ./host-firewall.sh status)"
  else bad "host packet-rate firewall not installed: run sudo ./host-firewall.sh"; fi
else
  warn "can't check host firewall without sudo: run sudo ./host-firewall.sh status"
fi

echo
echo "Result: $PASS passed, $FAIL failed, $WARN warnings"
[ "$FAIL" -eq 0 ]
