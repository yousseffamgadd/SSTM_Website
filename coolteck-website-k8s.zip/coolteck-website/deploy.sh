#!/usr/bin/env bash
# Build the CoolTeck website image, load it into the node's containerd and
# deploy it to Kubernetes (namespace "coolteck"). Run from this folder:
#   chmod +x deploy.sh && ./deploy.sh
set -euo pipefail

IMAGE="coolteck-web:1.0.0"
NS="coolteck"
cd "$(dirname "$0")"

# 1) Build and load the image into containerd (k8s.io namespace)
echo ">> Building $IMAGE"
if command -v docker >/dev/null 2>&1; then
  docker build -t "$IMAGE" .
  docker save "$IMAGE" -o /tmp/coolteck-image.tar
elif command -v nerdctl >/dev/null 2>&1; then
  sudo nerdctl --namespace k8s.io build -t "$IMAGE" .
elif command -v buildah >/dev/null 2>&1; then
  buildah bud -t "$IMAGE" .
  buildah push "$IMAGE" "docker-archive:/tmp/coolteck-image.tar:$IMAGE"
else
  echo "No docker, nerdctl or buildah found. Install one, e.g.: sudo apt install -y docker.io" >&2
  exit 1
fi

if [ -f /tmp/coolteck-image.tar ]; then
  echo ">> Importing image into containerd (k8s.io namespace)"
  sudo ctr -n k8s.io images import /tmp/coolteck-image.tar
  rm -f /tmp/coolteck-image.tar
fi

# 2) Serve on port 8080 of this node's private IP (Oracle Cloud maps the public IP to it)
PRIVATE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')
cat > k8s/03-public-ip.yaml <<PATCH
apiVersion: v1
kind: Service
metadata:
  name: coolteck-web
  namespace: coolteck
spec:
  externalIPs:
    - ${PRIVATE_IP}
PATCH

# An earlier combined version ran CoolTeck inside the ticketing namespace (sstm).
# Remove it there so ports 8080/30081 are free for this separate deployment.
if kubectl -n sstm get deployment coolteck-web >/dev/null 2>&1 || kubectl -n sstm get svc coolteck-web >/dev/null 2>&1; then
  echo ">> Removing old CoolTeck copy from the ticketing namespace"
  kubectl -n sstm delete deployment coolteck-web --ignore-not-found
  kubectl -n sstm delete svc coolteck-web --ignore-not-found
  kubectl -n sstm delete networkpolicy coolteck-access --ignore-not-found
fi

# 3) Deploy
echo ">> Applying manifests"
kubectl apply -k k8s/
kubectl -n "$NS" rollout restart deployment/coolteck-web >/dev/null
kubectl -n "$NS" rollout status deployment/coolteck-web --timeout=180s

echo
echo "Done. CoolTeck website: http://<public-ip>:8080  (or :30081)"
echo "Private IP serving port 8080: ${PRIVATE_IP}"
echo "Install the DoS firewall (once):  sudo ./host-firewall.sh"
echo "Check everything:                 ./verify.sh"
