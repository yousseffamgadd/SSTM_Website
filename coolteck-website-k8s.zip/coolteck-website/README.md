# CoolTeck website on Kubernetes (Ubuntu)

The CoolTeck static website, served by nginx in its own Kubernetes namespace (`coolteck`). It is a separate project from the SSTM ticketing site and can be deployed, updated or removed on its own.

```
Browser ──► public IP :8080 / :30081 ──► host firewall (packet-rate limits) ──► Service coolteck-web ──► Deployment coolteck-web (2 nginx pods)
```

Address: `http://<public-ip>:8080` (also `:30081`).

## Deploy (on the Ubuntu k8s node)

In the Oracle Console Security List, add ingress rules for TCP `8080` and `30081` (source `0.0.0.0/0`). Then:

```bash
cd /home/ubuntu/coolteck-website
chmod +x deploy.sh verify.sh host-firewall.sh
./deploy.sh
sudo ./host-firewall.sh
./verify.sh
```

## The Support button

The site files in `site/` are unchanged from the original, where the Support links (top menu and footer) point to `https://sstm-ticket.vercel.app/`. nginx rewrites that link as it serves each page, to the value of `TICKETING_URL` in `k8s/01-coolteck.yaml`.

The default is `http://$host:80/`: the same server the visitor used, on the ticketing site's port 80. A visitor on `http://130.162.166.80:8080` is sent to `http://130.162.166.80/` (browsers hide `:80` because it is the default HTTP port). To send visitors to the ticketing NodePort instead, change it to `http://$host:30080/`; once you have a domain, use the full address, e.g. `https://tickets.example.com/`. Apply a change with `kubectl apply -k k8s/` (no rebuild needed).

## Changing the content

Edit files in `site/` (or regenerate pages with the scripts in `site/source/`, as described in `site/README.md`) and run `./deploy.sh` again. `site/source/` and `site/README.md` are left out of the image and blocked by nginx, so they are never public.

## Protection

Per visitor IP, nginx allows 20 requests/second with a burst of 80 (a page loads about 10 files) and 50 open connections, caps request bodies at 16 KB, and closes connections that send headers or bodies too slowly (10 s). Change these in the `env` section of `k8s/01-coolteck.yaml`.

The host firewall (`sudo ./host-firewall.sh`) drops floods in the kernel before they reach Kubernetes, on ports 8080 and 30081 only: 20 new connections/second (burst 50) and 1,500 packets/second (burst 3,000) per IP, 500 new connections/second from all visitors together, and malformed TCP packets. The packet limit allows roughly 4 MB/s of downloads per visitor, which the 11 MB PDFs need. It uses its own iptables chain (`COOLTECK-DOS`) and boot service, separate from the ticketing site's. `sudo ./host-firewall.sh status` shows dropped packets; `sudo ./host-firewall.sh remove` removes only these rules.

The pods run as a non-root user with a read-only filesystem, and NetworkPolicy gives them no outbound network access (requires Calico, Cilium or another enforcing CNI).

## Useful commands

```bash
kubectl -n coolteck get pods,svc
kubectl -n coolteck logs deploy/coolteck-web -f
kubectl delete namespace coolteck      # remove the site completely
```

If you apply the manifests by hand, first create `k8s/03-public-ip.yaml` from `k8s/03-public-ip.yaml.example` with your node's private IP (`kubectl get nodes -o wide`).
