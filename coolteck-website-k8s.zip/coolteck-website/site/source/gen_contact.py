from build import page, write

body = """
  <section class="page-hero">
    <div class="container">
      <div class="breadcrumb"><a href="index.html">Home</a> / Contact</div>
      <h1>Get in touch</h1>
      <p>Questions about CoolTeck, pricing, pilots, or integration with your existing systems — reach out and the SSTM team will follow up.</p>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="grid-2" style="align-items:flex-start;">
        <div class="card">
          <div id="contact-success" class="form-success">Thanks — your message has been recorded. This is a demo form; connect it to your email or CRM to receive real submissions.</div>
          <form id="contact-form">
            <div class="form-grid">
              <div class="field">
                <label for="name">Full name</label>
                <input type="text" id="name" name="name" placeholder="Jane Doe" required />
              </div>
              <div class="field">
                <label for="email">Email address</label>
                <input type="email" id="email" name="email" placeholder="you@company.com" required />
              </div>
            </div>
            <div class="form-grid">
              <div class="field">
                <label for="company">Company</label>
                <input type="text" id="company" name="company" placeholder="Company name" />
              </div>
              <div class="field">
                <label for="topic">Topic</label>
                <select id="topic" name="topic">
                  <option>Product &amp; pricing</option>
                  <option>Technical / integration</option>
                  <option>Partnership</option>
                  <option>Support</option>
                  <option>Other</option>
                </select>
              </div>
            </div>
            <div class="field">
              <label for="message">Message</label>
              <textarea id="message" name="message" placeholder="Tell us about your cold chain setup and what you're looking for..." required></textarea>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Send message</button>
            <p class="form-note">This form is a front-end demo only for now &mdash; wire it up to an email service, form backend, or CRM before going live.</p>
          </form>
        </div>

        <div>
          <div class="contact-info">
            <div class="item">
              <div class="icon">&#128231;</div>
              <div>
                <h4>Email</h4>
                <a href="mailto:info@sstm-eg.com">info@sstm-eg.com</a>
              </div>
            </div>
            <div class="item">
              <div class="icon">&#127760;</div>
              <div>
                <h4>Website</h4>
                <a href="https://www.sstm-eg.com" target="_blank" rel="noopener">www.sstm-eg.com</a>
              </div>
            </div>
            <div class="item">
              <div class="icon">&#128205;</div>
              <div>
                <h4>Location</h4>
                <p>Cairo, Egypt</p>
              </div>
            </div>
            <div class="item">
              <div class="icon">&#128196;</div>
              <div>
                <h4>Prefer a document?</h4>
                <p><a href="brochure.html">Download the CoolTeck brochure</a> for a printable overview.</p>
              </div>
            </div>
          </div>
          <div class="note-banner" style="margin-top:22px;">
            Placeholder contact details above &mdash; swap in your real phone number, address and any additional office locations.
          </div>
        </div>
      </div>
    </div>
  </section>
"""

write("contact.html", page(
    title="Contact — CoolTeck",
    description="Get in touch with the SSTM team about CoolTeck cold chain monitoring sensors.",
    active="contact.html",
    body=body,
))
