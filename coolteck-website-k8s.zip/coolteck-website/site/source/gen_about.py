from build import page, write

body = """
  <section class="page-hero">
    <div class="container">
      <div class="breadcrumb"><a href="index.html">Home</a> / About</div>
      <h1>About CoolTeck &amp; SSTM</h1>
      <p>CoolTeck is the connected cold chain management product line built by SSTM — an Egypt-based IoT &amp; AIoT solutions company.</p>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="grid-2">
        <div>
          <span class="eyebrow">The product</span>
          <h2>CoolTeck: Connected Cold Chain Management</h2>
          <p>CoolTeck exists because temperature-sensitive goods — vaccines, pharmaceuticals, food — are too easily lost to a broken cold chain. Most vaccines only stay effective between 2&ndash;7&deg;C, and temperature excursions cost the healthcare industry an estimated $35 billion a year.</p>
          <p>CoolTeck's standalone and BLE sensors are designed around a simple philosophy: simple to install, rigid enough to rely on, able to run stand-alone or fully connected, and controllable without demanding constant attention.</p>
        </div>
        <div>
          <span class="eyebrow">The company</span>
          <h2>SSTM — Simply Smart</h2>
          <p>Established in 2016, SSTM Egypt is a provider of industry-grade IoT and Artificial Intelligence of Things (AIoT) solutions. Its founding team brings deep expertise in research, electronics design, information technology and product development.</p>
          <p>SSTM works across the full IoT value chain — 4G, Zigbee, BLE, LoRa and wired connectivity — building customized, machine-to-machine and AIoT platforms in partnership with multinational organizations.</p>
        </div>
      </div>
    </div>
  </section>

  <section style="background:var(--gray-100)">
    <div class="container">
      <div class="grid-2">
        <div class="card">
          <h3>Vision</h3>
          <p>SSTM envisions a connected world where AIoT solutions drive innovation, efficiency and improved quality of life across industries — staying at the forefront of digital transformation.</p>
        </div>
        <div class="card">
          <h3>Mission</h3>
          <p>To empower organizations to harness the full potential of AIoT and IoT through customized, high-quality solutions — guiding clients through digital transformation and end-to-end delivery that exceeds expectations.</p>
        </div>
      </div>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Core values</span>
        <h2>What SSTM builds on</h2>
      </div>
      <div class="grid-3">
        <div class="card"><h3>Integrity</h3><p>Honesty, transparency and trust in every interaction.</p></div>
        <div class="card"><h3>Innovation</h3><p>Continuous exploration of new technologies and ideas.</p></div>
        <div class="card"><h3>Teamwork</h3><p>A collaborative environment that values every contribution.</p></div>
        <div class="card"><h3>Agility</h3><p>Adapting quickly to changing market dynamics and customer needs.</p></div>
        <div class="card"><h3>Customer-oriented</h3><p>Understanding and exceeding customer expectations, always.</p></div>
        <div class="card"><h3>Ownership</h3><p>Accountability for the work and the impact it has.</p></div>
      </div>
    </div>
  </section>

  <section style="background:var(--gray-100)">
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">The SSTM family</span>
        <h2>CoolTeck is one of several SSTM product lines</h2>
        <p>SSTM builds a portfolio of semi-customized IoT products across smart cities, air quality, training and asset tracking.</p>
      </div>
      <div class="grid-4">
        <div class="card"><h3>IOTPIA</h3><p>Smart city automation — street lighting, waste management, smart parking.</p></div>
        <div class="card"><h3>AirZZen</h3><p>Low-power IoT air quality monitors.</p></div>
        <div class="card"><h3>CoolTeck</h3><p>Connected cold chain management — this product.</p></div>
        <div class="card"><h3>IOTiK</h3><p>IoT innovation training kit.</p></div>
      </div>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="cta-band">
        <h2>Want to know more about SSTM or CoolTeck?</h2>
        <p>Reach out — we're happy to walk through specs, pilots, or how CoolTeck fits into your existing systems.</p>
        <div class="cta-actions">
          <a class="btn btn-primary" href="contact.html">Contact us</a>
          <a class="btn btn-outline" href="https://www.sstm-eg.com" target="_blank" rel="noopener">Visit sstm-eg.com</a>
        </div>
      </div>
    </div>
  </section>
"""

write("about.html", page(
    title="About CoolTeck & SSTM",
    description="CoolTeck is the connected cold chain management product built by SSTM, an Egypt-based IoT & AIoT solutions company established in 2016.",
    active="about.html",
    body=body,
))
