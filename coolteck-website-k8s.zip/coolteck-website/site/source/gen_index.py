from build import page, write

body = """
  <section class="hero">
    <div class="container">
      <div>
        <div class="badge-row">
          <span>Connected Cold Chain Management</span>
          <span>Made in Egypt</span>
        </div>
        <h1>Real-time temperature &amp; humidity monitoring, built for cold chains that can't afford surprises.</h1>
        <p class="lead">CoolTeck is SSTM's IoT sensor platform for cold chain logistics, pharma storage and cold fleet transport — accurate readings, instant alerts, and full traceability from the point of storage to the point of delivery.</p>
        <div class="hero-actions">
          <a class="btn btn-primary" href="product.html">Explore the product</a>
          <a class="btn btn-outline" href="brochure.html">Download brochure</a>
        </div>
      </div>
      <div class="hero-visual">
        <img src="images/product-ble-sensor.png" alt="CoolTeck BLE temperature and humidity sensor" />
      </div>
    </div>
  </section>

  <section class="stat-strip tight">
    <div class="container stat-grid">
      <div class="stat"><b>2&ndash;7&deg;C</b><span>the window most vaccines must stay within</span></div>
      <div class="stat"><b>~$35B</b><span>lost yearly to temperature excursions in healthcare</span></div>
      <div class="stat"><b>&lt;0.3&deg;C</b><span>accuracy on CoolTeck's BLE sensor</span></div>
      <div class="stat"><b>200</b><span>readings stored locally per device for traceability</span></div>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Two form factors, one platform</span>
        <h2>A sensor for every point in the chain</h2>
        <p>From standalone 4G units in remote cold rooms to compact BLE beacons on the goods themselves, CoolTeck covers the full journey.</p>
      </div>
      <div class="grid-2">
        <div class="card">
          <div class="icon">&#128225;</div>
          <h3>CoolTeck Mobile / WiFi Sensor</h3>
          <p>Quadband 4G/GSM standalone temperature sensor built for remote areas, cold fleet and small cold rooms — no local network required.</p>
          <div class="tag-row">
            <span class="tag">Up to 4 sensors</span>
            <span class="tag">IP67</span>
            <span class="tag">&lt;0.5&deg;C error</span>
          </div>
        </div>
        <div class="card">
          <div class="icon">&#128167;</div>
          <h3>CoolTeck BLE Temp &amp; Humidity Sensor</h3>
          <p>A compact, battery-powered BLE beacon that travels with the goods — ideal for cold chain logistics and in-transit traceability.</p>
          <div class="tag-row">
            <span class="tag">Up to 3 yr battery</span>
            <span class="tag">IP66</span>
            <span class="tag">&lt;0.3&deg;C error</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="tight">
    <div class="container">
      <div class="cta-band" style="background:linear-gradient(120deg,var(--blue),var(--teal));">
        <h2>Not sure how many sensors your room needs?</h2>
        <p>The CoolTeck Sensor Placement Tool calculates sensor counts, exact wall coordinates and gateway placement from your room dimensions — then generates ready-to-share engineering reports.</p>
        <div class="cta-actions">
          <a class="btn btn-navy" href="sensor-tool.html">Open the placement tool</a>
        </div>
      </div>
    </div>
  </section>

  <section style="background:var(--gray-100)">
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Design philosophy</span>
        <h2>Simple to deploy. Rigid enough to trust.</h2>
        <p>CoolTeck devices are built to work standalone or fully connected, with zero interaction required once installed.</p>
      </div>
      <div class="philosophy-grid">
        <div class="philosophy-item"><div class="ring">S</div><h4>Simple</h4></div>
        <div class="philosophy-item"><div class="ring">R</div><h4>Rigid</h4></div>
        <div class="philosophy-item"><div class="ring">SA</div><h4>Stand-Alone</h4></div>
        <div class="philosophy-item"><div class="ring">C</div><h4>Connected</h4></div>
        <div class="philosophy-item"><div class="ring">NI</div><h4>No Interaction</h4></div>
        <div class="philosophy-item"><div class="ring">CT</div><h4>Controllable</h4></div>
      </div>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="cta-band">
        <h2>Part of the SSTM family of AIoT solutions</h2>
        <p>CoolTeck is developed by SSTM (Simply Smart), an Egypt-based IoT &amp; AIoT solutions provider building industry-grade connected products since 2016.</p>
        <div class="cta-actions">
          <a class="btn btn-primary" href="about.html">About CoolTeck &amp; SSTM</a>
          <a class="btn btn-outline" href="contact.html">Talk to us</a>
        </div>
      </div>
    </div>
  </section>
"""

write("index.html", page(
    title="CoolTeck by SSTM — Connected Cold Chain Management",
    description="CoolTeck is SSTM's IoT sensor platform for real-time cold chain temperature and humidity monitoring.",
    active="index.html",
    body=body,
))
