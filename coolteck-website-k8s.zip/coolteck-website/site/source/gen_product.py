from build import page, write

body = """
  <section class="page-hero">
    <div class="container">
      <div class="breadcrumb"><a href="index.html">Home</a> / Product</div>
      <h1>CoolTeck Product &amp; Features</h1>
      <p>Two purpose-built sensors, one connected cold chain platform. Below are the full specifications for both CoolTeck devices.</p>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="product-block">
        <div class="product-photo">
          <img src="images/product-mobile-sensor.png" alt="CoolTeck Mobile/WiFi wireless temperature sensor" />
        </div>
        <div>
          <span class="eyebrow">Standalone unit</span>
          <h2>CoolTeck Mobile / WiFi Sensor</h2>
          <p>A quadband 4G/GSM standalone temperature sensor built for real-time monitoring in remote areas, cold fleet vehicles and small cold rooms — wherever a fixed network connection isn't practical.</p>
          <table class="spec-table">
            <tr><td>Connectivity</td><td>Quadband 4G / GSM, standalone (no local network required)</td></tr>
            <tr><td>Best for</td><td>Remote areas, cold fleet transport, small cold rooms</td></tr>
            <tr><td>Form factor</td><td>10 &times; 10 &times; 4 cm</td></tr>
            <tr><td>Cloud integration</td><td>Seamlessly integrates with CoolTeck Cloud, or any MQTT / HTTP server</td></tr>
            <tr><td>Sensor inputs</td><td>Up to 4 sensors per module</td></tr>
            <tr><td>Configuration</td><td>Configurable via SMS (sensor types, ports / IP / port number, transmission period)</td></tr>
            <tr><td>Alerts</td><td>Integrated alarm buzzer</td></tr>
            <tr><td>Accuracy</td><td>Less than 0.5&deg;C error</td></tr>
            <tr><td>Power</td><td>Integrated power supply, 100&ndash;240V or 12V DC &middot; battery-based modules optional</td></tr>
            <tr><td>Protection rating</td><td>IP67 — splash, dust and water resistant</td></tr>
          </table>
        </div>
      </div>

      <div class="product-block reverse">
        <div class="product-photo">
          <img src="images/product-ble-sensor.png" alt="CoolTeck BLE temperature and humidity sensor" />
        </div>
        <div>
          <span class="eyebrow">In-transit beacon</span>
          <h2>CoolTeck BLE Temperature &amp; Humidity Sensor</h2>
          <p>A compact, long-life BLE beacon designed to travel with the goods themselves — built for cold chain logistics where the quality and potency of transported goods depends on an unbroken temperature record.</p>
          <table class="spec-table">
            <tr><td>Best for</td><td>Cold chain logistics — ensuring quality &amp; potency of transported goods</td></tr>
            <tr><td>Accuracy</td><td>Less than 0.3&deg;C error</td></tr>
            <tr><td>Data storage</td><td>Up to 200 local readings stored for traceability &amp; analysis</td></tr>
            <tr><td>Battery lifetime</td><td>Up to 3 years service life</td></tr>
            <tr><td>Broadcast</td><td>100m programmable BLE beacon, temperature + humidity</td></tr>
            <tr><td>Battery</td><td>Alkaline, 1000mAh &middot; ~24 months life at 1-second broadcast rate</td></tr>
            <tr><td>Protection rating</td><td>IP66 waterproof</td></tr>
            <tr><td>Dimensions</td><td>70.6 &times; 38 &times; 17.8 mm</td></tr>
            <tr><td>Gateway</td><td>Perfectly integratable with the IOTPIA Smart Gateway</td></tr>
          </table>
        </div>
      </div>
    </div>
  </section>

  <section style="background:var(--gray-100)">
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">How it works</span>
        <h2>From sensor to dashboard in four steps</h2>
      </div>
      <div class="flow">
        <div class="step">
          <div class="num">1</div>
          <h4>Sense</h4>
          <p>The CoolTeck device continuously measures temperature (and humidity, on the BLE unit) at the storage point or on the goods in transit.</p>
        </div>
        <div class="step">
          <div class="num">2</div>
          <h4>Transmit</h4>
          <p>Readings are sent over 4G/GSM, or broadcast via BLE to the nearest IOTPIA Gateway, with up to 200 readings buffered locally.</p>
        </div>
        <div class="step">
          <div class="num">3</div>
          <h4>Connect</h4>
          <p>Data flows into CoolTeck Cloud, or any MQTT / HTTP server your business already runs — no vendor lock-in.</p>
        </div>
        <div class="step">
          <div class="num">4</div>
          <h4>Alert &amp; trace</h4>
          <p>Out-of-range readings trigger the integrated alarm buzzer and cloud alerts, while the full history stays available for traceability and audits.</p>
        </div>
      </div>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Where it fits</span>
        <h2>Built for the environments cold chain failures hurt the most</h2>
      </div>
      <div class="grid-4">
        <div class="card"><div class="icon">&#128137;</div><h3>Pharma &amp; vaccines</h3><p>Keep sensitive stock inside the 2&ndash;7&deg;C window regulators require.</p></div>
        <div class="card"><div class="icon">&#128667;</div><h3>Cold fleet transport</h3><p>Monitor refrigerated vehicles in real time, even outside network coverage.</p></div>
        <div class="card"><div class="icon">&#127974;</div><h3>Cold storage rooms</h3><p>Standalone monitoring for small rooms without existing infrastructure.</p></div>
        <div class="card"><div class="icon">&#127865;</div><h3>Food &amp; logistics</h3><p>Traceable temperature records from warehouse to last-mile delivery.</p></div>
      </div>
    </div>
  </section>

  <section style="background:var(--gray-100)">
    <div class="container">
      <div class="section-head">
        <span class="eyebrow">Engineering &amp; documentation</span>
        <h2>Every installation is engineered, not eyeballed</h2>
        <p>CoolTeck deployments follow a WHO-informed thermal mapping methodology, with sensor counts, wall coordinates and gateway placement calculated from actual room dimensions — not rules of thumb.</p>
      </div>
      <div class="grid-3">
        <div class="card">
          <div class="icon">&#128203;</div>
          <h3>Coverage levels</h3>
          <p>Choose the rigor your room needs — from a full <b>WHO Testing</b> mapping study, to a <b>Pharmaceutical Level</b> deployment, down to <b>Minimal Coverage</b> for lower-risk spaces.</p>
        </div>
        <div class="card">
          <div class="icon">&#128682;</div>
          <h3>Door-sensor placement rule</h3>
          <p>No sensor is ever placed on a door leaf, opening, frame or moving hardware — door-risk points are calculated on fixed structure beside or above the opening instead.</p>
        </div>
        <div class="card">
          <div class="icon">&#128225;</div>
          <h3>Wired &amp; wireless, compared</h3>
          <p>Every room is designed both ways — wired gateways (4 sensors each) with full cable schedules, and wireless gateways (4/6/8/10 capacity) with calculated shared redundancy.</p>
        </div>
      </div>
      <div class="note-banner" style="margin-top:28px;">
        Try it yourself: the <a href="sensor-tool.html">CoolTeck Sensor Placement Tool</a> runs this exact methodology in your browser and generates the reports below directly from your room dimensions.
      </div>
      <div class="grid-4" style="margin-top:20px;">
        <div class="card">
          <h3>Executive report</h3>
          <p>A one-glance summary for management and site review.</p>
          <a class="btn btn-ghost btn-block" href="assets/sample-reports/short-executive-report.html" target="_blank">View sample</a>
        </div>
        <div class="card">
          <h3>Detailed design report</h3>
          <p>Full methodology, room-by-room figures and three coverage-level options.</p>
          <a class="btn btn-ghost btn-block" href="assets/sample-reports/detailed-design-report.html" target="_blank">View sample</a>
        </div>
        <div class="card">
          <h3>Wiring package</h3>
          <p>Gateway register and complete cable schedule with routing allowance.</p>
          <a class="btn btn-ghost btn-block" href="assets/sample-reports/wired-installation-wiring-package.html" target="_blank">View sample</a>
        </div>
        <div class="card">
          <h3>Approval &amp; release form</h3>
          <p>Room-by-room sign-off, verification checklist and handover attachments.</p>
          <a class="btn btn-ghost btn-block" href="assets/sample-reports/approval-site-release-form.html" target="_blank">View sample</a>
        </div>
      </div>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="cta-band">
        <h2>Ready to see full specs on paper?</h2>
        <p>Download the CoolTeck brochure for a printable overview of both devices, or get in touch to talk through your cold chain requirements.</p>
        <div class="cta-actions">
          <a class="btn btn-primary" href="brochure.html">Download brochure</a>
          <a class="btn btn-outline" href="contact.html">Contact sales</a>
        </div>
      </div>
    </div>
  </section>
"""

write("product.html", page(
    title="Product &amp; Features — CoolTeck",
    description="Full specifications for the CoolTeck Mobile/WiFi sensor and CoolTeck BLE Temperature & Humidity sensor.",
    active="product.html",
    body=body,
))
