#!/usr/bin/env python3
"""Generates the static CoolTeck site pages from shared header/footer + per-page content."""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # site root, one level up from source/

NAV_ITEMS = [
    ("index.html", "Home"),
    ("product.html", "Product"),
    ("about.html", "About"),
    ("brochure.html", "Brochure"),
    ("sensor-tool.html", "Sensor Tool"),
    ("feedback.html", "Support"),
]

def header(active):
    link_lines = []
    for href, label in NAV_ITEMS:
        cls = ' class="active"' if href == active else ''
        link_lines.append(f'        <a href="{href}"{cls}>{label}</a>')
    links = "\n".join(link_lines)
    return f"""  <header class="site-header">
    <div class="container nav-row">
      <a class="brand" href="index.html">
        <img src="images/coolteck-logo.png" alt="CoolTeck logo" />
        <span class="sub">by SSTM</span>
      </a>
      <nav class="main-nav">
{links}
      </nav>
      <div class="nav-cta">
        <a class="btn btn-navy" href="contact.html"><span class="long">Get in touch</span><span class="short">Contact</span></a>
        <button class="nav-toggle" aria-label="Toggle menu">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>
"""

FOOTER = """  <footer class="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <img src="images/coolteck-logo.png" alt="CoolTeck logo" />
          <p>Connected cold chain monitoring — real-time temperature &amp; humidity intelligence for pharma, food and logistics.</p>
        </div>
        <div>
          <h4>Product</h4>
          <ul>
            <li><a href="product.html">Features &amp; specs</a></li>
            <li><a href="brochure.html">Download brochure</a></li>
            <li><a href="sensor-tool.html">Sensor placement tool</a></li>
          </ul>
        </div>
        <div>
          <h4>Company</h4>
          <ul>
            <li><a href="about.html">About CoolTeck &amp; SSTM</a></li>
            <li><a href="https://sstm-ticket.vercel.app/">Support &amp; feedback</a></li>
            <li><a href="contact.html">Contact us</a></li>
          </ul>
        </div>
        <div>
          <h4>Get in touch</h4>
          <ul>
            <li><a href="mailto:info@sstm-eg.com">info@sstm-eg.com</a></li>
            <li><a href="https://www.sstm-eg.com" target="_blank" rel="noopener">www.sstm-eg.com</a></li>
            <li>Cairo, Egypt</li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <span>&copy; <span id="year"></span> CoolTeck. A product by SSTM (Simply Smart).</span>
        <span class="sstm-credit">Powered by <img src="images/favicon.png" alt="SSTM" /> SSTM</span>
      </div>
    </div>
  </footer>
  <script>document.getElementById('year').textContent = new Date().getFullYear();</script>
  <script src="js/main.js"></script>
"""

def page(title, description, active, body, extra_head=""):
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>{title}</title>
<meta name="description" content="{description}" />
<link rel="icon" href="images/favicon.png" />
<link rel="stylesheet" href="css/style.css" />
{extra_head}</head>
<body>
{header(active)}
{body}
{FOOTER}
</body>
</html>
"""

def write(name, html):
    path = os.path.join(ROOT, name)
    with open(path, "w") as f:
        f.write(html)
    print("wrote", name)
