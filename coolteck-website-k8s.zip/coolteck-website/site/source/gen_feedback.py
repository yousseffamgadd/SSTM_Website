from build import page, write

body = """
  <section class="placeholder-wrap">
    <div class="container">
      <div class="placeholder-card" style="margin:0 auto;">
        <span class="status-chip">Coming soon</span>
        <div class="icon-lg">&#128172;</div>
        <h1>Customer Feedback &amp; Ticketing</h1>
        <p>A dedicated portal for submitting support tickets, tracking their status and sharing feedback on CoolTeck devices is on its way. In the meantime, reach the team directly and we'll make sure it's handled.</p>
        <div id="notify-success" class="form-success">Thanks — we'll let you know as soon as the portal is live.</div>
        <form data-notify-form>
          <div class="field" style="text-align:left;">
            <label for="notify-email">Get notified when it launches</label>
            <input type="email" id="notify-email" placeholder="you@company.com" required />
          </div>
          <button type="submit" class="btn btn-primary btn-block">Notify me</button>
        </form>
        <p class="form-note">Need help right now? <a href="contact.html">Contact us directly</a> instead.</p>
      </div>
    </div>
  </section>
"""

write("feedback.html", page(
    title="Customer Feedback & Ticketing — CoolTeck",
    description="A customer feedback and support ticketing portal for CoolTeck is coming soon.",
    active="feedback.html",
    body=body,
))
