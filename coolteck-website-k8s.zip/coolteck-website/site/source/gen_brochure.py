from build import page, write

body = """
  <section class="page-hero">
    <div class="container">
      <div class="breadcrumb"><a href="index.html">Home</a> / Brochure</div>
      <h1>Download the CoolTeck Brochure</h1>
      <p>A printable one-page overview of both CoolTeck devices &mdash; specs, use cases and how the platform fits together.</p>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="grid-2" style="align-items:center;">
        <div>
          <span class="eyebrow">PDF &middot; 1 page</span>
          <h2>Everything on one sheet</h2>
          <p>The brochure covers the CoolTeck Mobile/WiFi sensor and the CoolTeck BLE Temperature &amp; Humidity sensor, side by side, with full specifications and target use cases &mdash; ready to share with procurement, facilities or logistics teams.</p>
          <a class="btn btn-primary" href="assets/coolteck-brochure.pdf" download>&#11015; Download brochure (PDF)</a>
          <p class="form-note">This is a starter brochure generated from the current product specs &mdash; swap in your final branding, pricing and photography before sending it to customers.</p>
        </div>
        <div class="product-photo">
          <img src="images/coolteck-logo.png" alt="CoolTeck brochure" style="max-width:280px;" />
        </div>
      </div>
    </div>
  </section>
"""

write("brochure.html", page(
    title="Download Brochure — CoolTeck",
    description="Download the CoolTeck product brochure covering both the Mobile/WiFi and BLE Temperature & Humidity sensors.",
    active="brochure.html",
    body=body,
))
